#!/bin/bash
set -euo pipefail
project_dir="$(cd "$(dirname "$0")/.." && pwd)"
echo "Open http://127.0.0.1:8765 in your browser. Press Control-C to stop."
python3 -m http.server 8765 --bind 127.0.0.1 --directory "$project_dir/ios/ParcelAndPort/Web"
