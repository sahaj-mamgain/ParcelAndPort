// This harness verifies application event/state wiring, not browser layout or rendering.
const {test}=require('node:test');
const assert=require('node:assert/strict');
const vm=require('node:vm');
const fs=require('node:fs');
const E=require('../ios/ParcelAndPort/Web/engine.js');
const V=require('../ios/ParcelAndPort/Web/visuals.js');
const source=fs.readFileSync(require.resolve('../ios/ParcelAndPort/Web/app.js'),'utf8');
const KEY='parcel-and-port.save.v1';
function harness({saved,nativeSave,blockedStorage=false,reducedMotion=false}={}){
  const listeners={},windowListeners={},timers=new Map(),storage=new Map();let nextTimer=1;
  if(saved)storage.set(KEY,typeof saved==='string'?saved:E.serialize(saved));
  function node(){return {innerHTML:'',textContent:'',value:'',open:false,classList:{add(){},remove(){}},showModal(){this.open=true;},close(){this.open=false;},addEventListener(){}};}
  const nodes=new Map(['app','modal','toast'].map(id=>[id,node()]));
  const document={hidden:false,getElementById(id){if(!nodes.has(id))nodes.set(id,node());return nodes.get(id);},addEventListener(type,fn){listeners[type]=fn;}};
  const posts=[];const window={Parcel:E,ParcelVisuals:V,matchMedia(){return {matches:reducedMotion};},addEventListener(type,fn){windowListeners[type]=fn;}};
  if(nativeSave){window.__PARCEL_NATIVE_SAVE__=E.serialize(nativeSave);window.webkit={messageHandlers:{parcelSave:{postMessage(v){posts.push(v);}}}};}
  const localStorage={getItem(k){if(blockedStorage)throw Error('storage blocked');return storage.get(k)||null;},setItem(k,v){if(blockedStorage)throw Error('storage blocked');storage.set(k,v);}};
  const context={window,document,localStorage,FormData:class{constructor(target){this.values=target.values;}get(k){return this.values[k];}getAll(k){return this.values[k]||[];}},console,setTimeout(fn,delay){const id=nextTimer++;timers.set(id,{fn,delay});return id;},clearTimeout(id){timers.delete(id);}};
  vm.runInNewContext(source,context);
  return {nodes,document,timers,posts,storage,
    html:()=>nodes.get('app').innerHTML,modal:()=>nodes.get('modal').innerHTML,state:()=>E.restore(storage.get(KEY)),
    click(action,data={}){listeners.click({target:{closest(){return {dataset:{action,...data},disabled:false};}}});},
    input(seat,field,value){listeners.input({target:{dataset:{seat:String(seat),field},value}});},
    change(id,value){listeners.change({target:{id,value,dataset:{}}});},
    submit(id,values={}){listeners.submit({preventDefault(){},target:{id,values}});},
    hidden(value){document.hidden=value;listeners.visibilitychange();},
    runTimer(){const item=[...timers].find(([,v])=>v.delay<4000);if(!item)return false;timers.delete(item[0]);item[1].fn();return true;}
  };
}
const game=()=>E.createGame({seed:10,players:[{name:'A',ai:'human'},{name:'B',ai:'human'},{name:'C',ai:'human'}]});
test('lobby starts with four seats and adds up to eight, never nine',()=>{
  const h=harness();assert.match(h.html(),/4 \/ 8 seats/);for(let i=0;i<6;i++)h.click('add');assert.match(h.html(),/8 \/ 8 seats/);assert.equal((h.html().match(/class="seat"/g)||[]).length,8);h.click('start');assert.equal(h.state().players.length,8);assert.match(h.modal(),/Pass the device/);
});
test('selected board and player names reach the game without markup injection',()=>{
  const h=harness();h.input(0,'name','<img src=x onerror=bad>');h.click('board',{board:'alpine'});h.click('start');assert.equal(h.state().boardId,'alpine');assert.match(h.modal(),/&lt;img/);assert.doesNotMatch(h.modal(),/<img src=x/);assert.match(h.html(),/Alpine Trails/);
});
test('continuing and handing off preserve a saved turn until the next roll',()=>{
  const s=game();s.phase='end';const h=harness({saved:s});h.click('resume');assert.match(h.modal(),/A\./);h.click('close');h.click('end');assert.match(h.modal(),/B\./);assert.equal(h.state().phase,'roll');assert.equal(h.state().current,1);assert.equal(h.state().dice.length,0);h.click('close');assert.equal(h.state().phase,'roll');
});
test('starting a replacement match requires its explicit confirmation button',()=>{
  const s=game(),h=harness({saved:s});h.click('start');assert.match(h.modal(),/replaces the saved game/);assert.equal(h.state().players[0].name,'A');h.click('close');assert.equal(h.state().players[0].name,'A');h.click('start');h.click('start-confirm');assert.equal(h.state().players[0].name,'You');
});
test('auction UI routes a bid, prompts the next player and closes after passes',()=>{
  let s=game();s.phase='offer';s.players[0].position=1;s=E.act(s,{type:'auction'});const h=harness({saved:s});h.click('resume');h.click('close');h.nodes.set('bid-amount',{value:'20'});h.submit('bid-form');assert.equal(h.state().auction.bid,20);assert.match(h.modal(),/B\./);h.click('close');h.click('pass');assert.match(h.modal(),/C\./);h.click('close');h.click('pass');assert.equal(h.state().deeds[1].owner,0);assert.equal(h.state().players[0].cash,1380);assert.equal(h.state().phase,'end');
});
test('trade review does not transfer assets until acceptance',()=>{
  let s=game();s.deeds[1].owner=0;s=E.act(s,{type:'propose',target:1,giveIds:[1],takeCash:100});const h=harness({saved:s});h.click('resume');h.click('close');h.click('review-trade');assert.match(h.modal(),/B receives/);assert.equal(h.state().deeds[1].owner,0);h.click('accept');assert.equal(h.state().deeds[1].owner,1);assert.equal(h.state().players[0].cash,1500);assert.match(h.modal(),/A\./);
});
test('portfolio controls persist mortgage and redemption decisions',()=>{
  let s=game();s.deeds[1].owner=0;const h=harness({saved:s});h.click('resume');h.click('close');h.click('tile',{id:'1'});assert.match(h.modal(),/Mortgage property/);h.click('mortgage',{id:'1'});assert(h.state().deeds[1].mortgaged);assert.match(h.modal(),/Redeem mortgage/);h.click('redeem',{id:'1'});assert.equal(h.state().deeds[1].mortgaged,false);assert.equal(h.state().players[0].cash,1395);
});
test('opening a dialog and backgrounding the app pause AI decisions',()=>{
  const s=E.createGame({seed:10,players:[{name:'AI A',ai:'balanced'},{name:'AI B',ai:'bold'}]}),h=harness({saved:s});h.click('resume');assert(h.timers.size>0);h.click('menu');assert.equal(h.timers.size,0);h.click('close');assert(h.timers.size>0);h.hidden(true);assert.equal(h.timers.size,0);h.hidden(false);assert(h.timers.size>0);assert(h.runTimer());assert.notEqual(h.state().phase,'roll');
});
test('invalid save and unavailable browser storage show readable notices',()=>{
  const bad=harness({saved:'{broken'});assert.match(bad.html(),/previous save could not be read/);const blocked=harness({blockedStorage:true});blocked.click('start');assert.match(blocked.html(),/Autosave is unavailable/);
});
test('native backup restores and receives each subsequent saved state',()=>{
  const s=game(),h=harness({nativeSave:s,blockedStorage:true});h.click('resume');h.click('close');h.click('roll');assert.equal(h.posts.length,1);const saved=E.restore(h.posts[0]);assert.equal(saved.dice.length,2);assert.doesNotMatch(h.html(),/Autosave is unavailable/);
});
test('rolling commits once, locks gameplay during movement and ends at the saved outcome',()=>{
  const s=game(),h=harness({saved:s});h.click('resume');h.click('close');h.click('roll');const committed=h.storage.get(KEY);assert.match(h.html(),/Movement animation/);h.click('roll');assert.equal(h.storage.get(KEY),committed);for(let i=0;i<30&&/Movement animation/.test(h.html());i++)h.runTimer();assert.doesNotMatch(h.html(),/Movement animation/);assert.equal(h.storage.get(KEY),committed);
});
test('skipping an animation cannot reroll dice or run stale movement callbacks',()=>{
  const h=harness({saved:game()});h.click('resume');h.click('close');h.click('roll');const committed=h.storage.get(KEY);h.click('skip-motion');assert.doesNotMatch(h.html(),/Movement animation/);for(let i=0;i<20;i++)h.runTimer();assert.equal(h.storage.get(KEY),committed);
});
test('backgrounding during animation displays the committed move on return',()=>{
  const h=harness({saved:game()});h.click('resume');h.click('close');h.click('roll');const committed=h.storage.get(KEY);h.hidden(true);assert.doesNotMatch(h.html(),/Movement animation/);h.hidden(false);assert.equal(h.storage.get(KEY),committed);
});
test('system Reduce Motion bypasses the dice and movement animation',()=>{
  const h=harness({saved:game(),reducedMotion:true});h.click('resume');h.click('close');h.click('roll');assert.doesNotMatch(h.html(),/Movement animation/);assert.equal(h.state().dice.length,2);
});
test('camera controls preserve gameplay and persist the selected view',()=>{
  const h=harness({saved:game()});h.click('resume');h.click('close');const before=h.storage.get(KEY);h.click('camera',{camera:'top'});assert.match(h.html(),/data-camera="top"/);assert.equal(h.storage.get(KEY),before);assert.equal(JSON.parse(h.storage.get('parcel-and-port.settings.v2')).camera,'top');h.click('camera',{camera:'follow'});assert.match(h.html(),/data-camera="follow"/);
});

test('buying through a button without a tile id refreshes ownership and turn controls',()=>{
  const s=game();s.players[0].position=1;s.phase='offer';const h=harness({saved:s});h.click('resume');h.click('close');h.click('buy');assert.equal(h.state().deeds[1].owner,0);assert.match(h.html(),/owned by A/);assert.match(h.html(),/data-action="end"/);assert.doesNotMatch(h.html(),/data-action="buy"/);
});
