const {test}=require('node:test');
const assert=require('node:assert/strict');
const E=require('../ios/ParcelAndPort/Web/engine.js');
const V=require('../ios/ParcelAndPort/Web/visuals.js');
test('all three boards form a continuous square perimeter with four corners',()=>{
  for(const b of E.BOARDS){
    const cells=b.tiles.map(t=>V.cell(b.size,t.id));assert.equal(cells.filter(c=>c.corner).length,4);
    assert(Math.abs(cells.reduce((sum,c)=>sum+c.w*c.h,0)-(640*640-460*460))<.00001);
    for(const c of cells){assert(c.x>=-.00001&&c.y>=-.00001&&c.x+c.w<=640.00001&&c.y+c.h<=640.00001);}
    for(let i=0;i<cells.length;i++)for(let j=i+1;j<cells.length;j++){
      const a=cells[i],b=cells[j],overlapX=Math.min(a.x+a.w,b.x+b.w)-Math.max(a.x,b.x),overlapY=Math.min(a.y+a.h,b.y+b.h)-Math.max(a.y,b.y);assert(overlapX<.00001||overlapY<.00001,'Tiles must not overlap');
    }
    assert.deepEqual([0,b.size/4,b.size/2,b.size*3/4].map(id=>{const c=V.cell(b.size,id);return [c.x,c.y];}),[[550,550],[0,550],[0,0],[550,0]]);
  }
});
test('every square can place eight distinct player anchors within its bounds',()=>{
  for(const b of E.BOARDS)for(const t of b.tiles){const c=V.cell(b.size,t.id),points=Array.from({length:8},(_,i)=>V.tokenPoint(b.size,t.id,i,8));assert.equal(new Set(points.map(p=>p.x.toFixed(3)+','+p.y.toFixed(3))).size,8);for(const p of points)assert(p.x>=c.x-.001&&p.x<=c.x+c.w+.001&&p.y>=c.y-.001&&p.y<=c.y+c.h+.001);}
});
test('animated dice paths use the engine result and include forward/backward event movement',()=>{
  for(const card of [2,3,4,8]){let s=E.createGame({seed:10});s.deck=[card];const after=E.act(s,{type:'roll'}),trail=V.movement(s,after);assert.deepEqual(trail.slice(0,4).map(x=>x.position),[1,2,3,4]);assert.equal(trail.at(-1).position,after.players[0].position);if(card===2)assert.deepEqual(trail.slice(4).map(x=>x.position),[5,6,7]);if(card===3)assert.deepEqual(trail.slice(4).map(x=>x.position),[3,2]);if([4,8].includes(card))assert(trail.at(-1).teleport);}
});
test('waiting out a delay produces no fake dice movement',()=>{
  const s=E.createGame();s.players[0].skipTurns=1;const after=E.act(s,{type:'roll'});assert.deepEqual(V.movement(s,after),[]);
});
test('all eight original pieces and every board have illustration markup',()=>{
  assert.equal(new Set(V.TOKEN_NAMES).size,8);for(let i=0;i<8;i++)assert.match(V.token(i),/<svg/);for(const b of E.BOARDS)for(const t of b.tiles)assert.match(t.type==='property'?V.building(b.id,t.id,t.color,3):V.special(t.type),/<svg/);
});
test('six-sided dice contain six faces with the requested settled orientation',()=>{
  for(let n=1;n<=6;n++){const html=V.die(n);assert.equal((html.match(/class="die-face /g)||[]).length,6);assert.match(html,/--die-x:/);assert.match(html,/--die-y:/);}
});
