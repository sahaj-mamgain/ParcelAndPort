/* Parcel & Port: original, offline WebGL miniature renderer. No remote assets. */
(function(root,factory){const api=factory(typeof module==='object'&&module.exports?require('./visuals.js'):root.ParcelVisuals);if(typeof module==='object'&&module.exports)module.exports=api;else root.Parcel3D=api;})(typeof globalThis!=='undefined'?globalThis:this,function(V){
  'use strict';
  const TAU=Math.PI*2,WHITE='#fff5db',INK='#243f4e';
  const rgb=h=>[1,3,5].map(i=>parseInt(h.slice(i,i+2),16)/255);
  const sub=(a,b)=>a.map((v,i)=>v-b[i]);
  const dot=(a,b)=>a.reduce((n,v,i)=>n+v*b[i],0);
  const norm=a=>{const l=Math.hypot(...a)||1;return a.map(v=>v/l);};
  const cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
  const world=(x,z)=>[(x-320)/32,(z-320)/32];
  function camera(width,height,mode='angled',yaw=0){
    const elevation=mode==='top'?Math.PI/2:mode==='follow'?.96:.8;
    const r=[Math.cos(yaw),0,-Math.sin(yaw)],u=[-Math.sin(yaw)*Math.sin(elevation),Math.cos(elevation),-Math.cos(yaw)*Math.sin(elevation)],f=[Math.sin(yaw)*Math.cos(elevation),Math.sin(elevation),Math.cos(yaw)*Math.cos(elevation)];
    const aspect=Math.max(.1,width/Math.max(1,height));
    let extentX=0,extentY=0;
    for(const x of [-10.5,10.5])for(const z of [-10.5,10.5])for(const y of [-.6,1.1]){extentX=Math.max(extentX,Math.abs(dot(r,[x,y,z])));extentY=Math.max(extentY,Math.abs(dot(u,[x,y,z])));}
    const hh=Math.max(extentY,extentX/aspect)*1.035,hw=hh*aspect;
    return {r,u,f,hw,hh,matrix:new Float32Array([r[0]/hw,u[0]/hh,-f[0]/60,0,r[1]/hw,u[1]/hh,-f[1]/60,0,r[2]/hw,u[2]/hh,-f[2]/60,0,0,0,0,1])};
  }
  function project(c,p,width,height){return {x:(dot(c.r,p)/c.hw+1)*width/2,y:(1-dot(c.u,p)/c.hh)*height/2};}
  function pick(c,x,y,width,height,size){
    const sx=(x/width*2-1)*c.hw,sy=(1-y/height*2)*c.hh;
    const o=c.r.map((v,i)=>v*sx+c.u[i]*sy+c.f[i]*50),t=(o[1]-.425)/c.f[1],wx=o[0]-c.f[0]*t,wz=o[2]-c.f[2]*t,px=wx*32+320,pz=wz*32+320;
    for(let id=0;id<size;id++){const a=V.cell(size,id);if(px>=a.x&&px<a.x+a.w&&pz>=a.y&&pz<a.y+a.h)return id;}
    return null;
  }
  function anchor(size,position,slot=0,count=1){
    const c=V.cell(size,position),cols=count>1?(c.corner&&count>4?3:2):1,rows=Math.ceil(count/cols),dx=(slot%cols-(cols-1)/2)*23,dy=count>1?(count>4&&!c.corner?0:17)+(Math.floor(slot/cols)-(rows-1)/2)*17:26,a=c.angle*Math.PI/180;
    const [x,z]=world(c.cx+dx*Math.cos(a)-dy*Math.sin(a),c.cy+dx*Math.sin(a)+dy*Math.cos(a));
    return {x,z,scale:count>4?.65:count>2?.85:1.22};
  }
  class Mesh {
    constructor(){this.vertices=[];}
    tri(a,b,c,color,uvs){const n=norm(cross(sub(b,a),sub(c,a))),co=typeof color==='string'?rgb(color):color;[a,b,c].forEach((p,i)=>this.vertices.push(...p,...n,...co,...(uvs?uvs[i]:[0,0])));}
    quad(a,b,c,d,color,uvs){this.tri(a,b,c,color,uvs&&[uvs[0],uvs[1],uvs[2]]);this.tri(a,c,d,color,uvs&&[uvs[0],uvs[2],uvs[3]]);}
    box(x,y,z,w,h,d,color,bevel=0){
      if(bevel){const b=Math.min(bevel,w/4,d/4,h/3),rings=[[-h/2,w/2-b,d/2-b],[-h/2+b,w/2,d/2],[h/2-b,w/2,d/2],[h/2,w/2-b,d/2-b]];
        const pts=rings.map(([yy,xx,zz])=>[[-xx+b,-zz], [xx-b,-zz],[xx,-zz+b],[xx,zz-b],[xx-b,zz],[-xx+b,zz],[-xx,zz-b],[-xx,-zz+b]].map(([a,c])=>[x+a,y+yy,z+c]));
        for(let k=0;k<3;k++)for(let i=0;i<8;i++)this.quad(pts[k][(i+1)%8],pts[k][i],pts[k+1][i],pts[k+1][(i+1)%8],color);
        for(let i=0;i<8;i++){this.tri([x,y+h/2,z],pts[3][(i+1)%8],pts[3][i],color);this.tri([x,y-h/2,z],pts[0][i],pts[0][(i+1)%8],color);}return;
      }
      const a=[x-w/2,y-h/2,z-d/2],b=[x+w/2,y+h/2,z+d/2];
      this.quad([a[0],b[1],a[2]],[a[0],b[1],b[2]],[b[0],b[1],b[2]],[b[0],b[1],a[2]],color);
      this.quad([a[0],a[1],b[2]],[a[0],b[1],b[2]],[a[0],b[1],a[2]],[a[0],a[1],a[2]],color);
      this.quad([b[0],a[1],a[2]],[b[0],b[1],a[2]],[b[0],b[1],b[2]],[b[0],a[1],b[2]],color);
      this.quad([a[0],a[1],a[2]],[a[0],b[1],a[2]],[b[0],b[1],a[2]],[b[0],a[1],a[2]],color);
      this.quad([b[0],a[1],b[2]],[b[0],b[1],b[2]],[a[0],b[1],b[2]],[a[0],a[1],b[2]],color);
    }
    cylinder(x,y,z,r,h,color,top=r,n=16){
      for(let i=0;i<n;i++){const a=i/n*TAU,b=(i+1)/n*TAU,p=[x+Math.cos(a)*r,y,z+Math.sin(a)*r],q=[x+Math.cos(b)*r,y,z+Math.sin(b)*r],s=[x+Math.cos(a)*top,y+h,z+Math.sin(a)*top],t=[x+Math.cos(b)*top,y+h,z+Math.sin(b)*top];this.quad(p,s,t,q,color);if(top)this.tri([x,y+h,z],t,s,color);}
    }
    sphere(x,y,z,rx,ry,rz,color,n=12){
      const p=(a,b)=>[x+rx*Math.sin(a)*Math.cos(b),y+ry*Math.cos(a),z+rz*Math.sin(a)*Math.sin(b)];
      for(let j=0;j<8;j++)for(let i=0;i<n;i++){const a=j/8*Math.PI,b=(j+1)/8*Math.PI,c=i/n*TAU,d=(i+1)/n*TAU;this.quad(p(a,c),p(a,d),p(b,d),p(b,c),color);}
    }
    roof(x,y,z,w,h,d,color){const a=[x-w/2,y,z-d/2],b=[x+w/2,y,z-d/2],c=[x+w/2,y,z+d/2],e=[x-w/2,y,z+d/2],p=[x,y+h,z-d/2],q=[x,y+h,z+d/2];this.tri(b,a,p,color);this.tri(q,e,c,color);this.quad(e,q,p,a,color);this.quad(q,c,b,p,color);}
  }
  function tree(m,x,z,s=1,snow=false){m.cylinder(x,.45,z,.08*s,.55*s,'#9c7451');if(snow){m.cylinder(x,.8*s,z,.53*s,.9*s,'#398d7e',0,9);m.cylinder(x,1.17*s,z,.4*s,.8*s,'#dceef0',0,9);}else{m.sphere(x,1.17*s,z,.47*s,.6*s,.47*s,'#67ad85');m.sphere(x-.2*s,1.2*s,z+.1*s,.27*s,.4*s,.3*s,'#98c779');}}
  function house(m,x,z,s,color,alpine=false,level=0){
    const y=.44,h=(.48+level*.22)*s;m.box(x,y+h/2,z,.68*s,h,.6*s,alpine?'#e6c5a1':'#fff0d4',.035*s);m.roof(x,y+h,z,.83*s,.34*s,.75*s,alpine?'#ebf3ee':color);m.box(x,y+.19*s,z+.305*s,.15*s,.36*s,.025*s,'#375e68');for(const dx of [-.23,.23])m.box(x+dx*s,y+h*.64,z+.315*s,.12*s,.17*s,.025*s,'#74bfc3');m.box(x+.23*s,y+h+.2*s,z-.15*s,.11*s,.28*s,.13*s,'#c08772');
  }
  function tokenMesh(id,color){
    const m=new Mesh();m.cylinder(0,0,0,.44,.12,color,.44,24);m.cylinder(0,.12,0,.36,.035,WHITE,.36,24);
    switch(id%8){
      case 0: m.sphere(0,.35,0,.48,.17,.23,color);m.box(0,.78,0,.045,.9,.045,'#bd935d');m.tri([-.04,1.25,0],[-.43,.51,0],[-.04,.51,0],WHITE);m.tri([.03,1.16,0],[.03,.51,0],[.41,.51,0],color);break;
      case 1: m.box(0,.3,0,.28,.25,.27,'#b77b48',.03);for(const x of [-.13,.13])for(const z of [-.1,.1])m.box(x,.52,z,.025,.38,.025,'#d4b781');m.sphere(0,1.12,0,.43,.54,.43,color,18);m.sphere(0,1.13,.016,.22,.55,.43,WHITE,18);break;
      case 2: m.cylinder(0,.3,0,.21,.76,WHITE,.28,18);m.cylinder(0,1.06,0,.28,.42,color,0,18);m.sphere(0,.85,.245,.13,.13,.035,'#29566b');m.sphere(-.04,.9,.27,.035,.035,.02,'#a2e5e8');for(let i=0;i<3;i++){const a=i*TAU/3;m.tri([0,.78,0],[Math.cos(a)*.4,.19,Math.sin(a)*.4],[Math.cos(a)*.16,.19,Math.sin(a)*.16],color);}m.cylinder(0,.19,0,.14,.2,'#edaf43',.08);break;
      case 3: m.sphere(0,.5,0,.3,.38,.26,color);m.sphere(.3,.4,-.1,.32,.19,.19,color);m.sphere(0,.97,0,.38,.29,.27,color);for(const x of [-.23,.23])m.cylinder(x,1.06,0,.17,.36,color,0,4);m.sphere(0,.85,.21,.24,.16,.14,WHITE);for(const x of [-.17,.17])m.sphere(x,1.01,.24,.045,.045,.03,INK);m.sphere(0,.9,.34,.055,.045,.04,INK);break;
      case 4: m.cylinder(0,.25,0,.3,.08,'#d7ab5c',.3,8);m.box(0,.65,0,.43,.72,.38,'#ffd778',.04);for(const x of [-.25,.25])for(const z of [-.22,.22])m.box(x,.66,z,.055,.82,.055,color);m.roof(0,1.05,0,.64,.24,.57,color);m.sphere(0,1.36,0,.12,.13,.07,'#d7ab5c');m.sphere(0,.62,.23,.08,.2,.025,WHITE);break;
      case 5: for(const x of [-.16,.16]){m.box(x,.3,0,.19,.28,.25,color,.035);m.box(x*2.2,.64,0,.16,.43,.17,color,.04);}m.box(0,.69,0,.45,.43,.31,color,.06);m.box(0,1.05,0,.62,.4,.42,'#e4e8e5',.06);m.box(0,1.07,.218,.46,.16,.025,INK,.015);for(const x of [-.13,.13])m.sphere(x,1.08,.24,.035,.04,.025,'#9ce8cf');m.cylinder(0,1.25,0,.025,.18,'#b9c9c7');m.sphere(0,1.45,0,.07,.07,.07,color);m.sphere(0,.7,.17,.08,.08,.025,'#ffe0a1');break;
      case 6: m.cylinder(0,.18,0,.11,.3,'#b68a5e');for(let i=0;i<3;i++)m.cylinder(0,.35+i*.29,0,.43-i*.1,.63,color,0,10);m.sphere(-.18,.75,.22,.065,.065,.065,'#f5cf6c');m.sphere(.14,.98,.11,.065,.065,.065,WHITE);break;
      case 7: m.cylinder(0,.18,0,.14,.25,'#cda35c');m.sphere(0,.86,0,.48,.5,.16,'#d7ab60',20);m.sphere(0,.86,.13,.4,.42,.04,WHITE,20);m.tri([0,1.21,.18],[-.09,.83,.18],[.09,.83,.18],color);m.tri([0,.5,.18],[.09,.83,.18],[-.09,.83,.18],INK);m.sphere(0,.84,.2,.055,.055,.025,'#d7ab60');break;
    }
    return m;
  }
  function scenery(board,light=false){
    const m=new Mesh(),night=board.id==='metro',snow=board.id==='alpine';
    m.box(0,-.32,0,20.7,.8,20.7,night?'#21394d':'#316a65',.15);m.box(0,.12,0,20.45,.25,20.45,'#dfc88e',.1);m.box(0,.32,0,20.1,.2,20.1,WHITE,.05);
    m.box(0,.44,0,14.24,.09,14.24,night?'#385b6d':snow?'#dae8e8':'#69c3c1',.03);
    if(board.id==='harbor'){
      m.box(-2.1,.51,-1.3,9.8,.15,11.4,'#a8ce9c',.06);m.box(-2.1,.6,-1.3,8.4,.04,1.05,'#e0d8bd');m.box(-2.3,.6,-1.3,1.05,.04,10.5,'#e0d8bd');
      for(let row=0;row<3;row++)for(let col=0;col<3;col++){if(row===1&&col===1)continue;const x=-5.4+col*2.5,z=-5.7+row*3.2;house(m,x,z,1.5,['#ed9c74','#e9b956','#549eac'][(row+col)%3]);tree(m,x+1,z+.7,.65);}
      for(let i=0;i<4;i++){m.box(3.2,.62,-4.5+i*2.6,2.3,.14,.37,'#ba9473');for(let j=0;j<4;j++)m.box(2.2+j*.6,.71,-4.5+i*2.6,.035,.025,.38,'#e0c596');}
      m.cylinder(5.4,.5,-5.3,.62,.3,'#dbd5b3');m.cylinder(5.4,.8,-5.3,.4,1.8,'#f7e8cf',.29,20);m.cylinder(5.4,1.65,-5.3,.35,.35,'#e77e62',.33,20);m.cylinder(5.4,2.6,-5.3,.44,.12,'#ce775e',.44,16);m.cylinder(5.4,2.72,-5.3,.25,.4,'#f9d985',.25,12);m.cylinder(5.4,3.12,-5.3,.47,.24,'#386471',0,16);
      for(let i=0;i<3;i++){const x=4.8+(i%2)*.6,z=-2.9+i*2.5;m.sphere(x,.72,z,.28,.18,.65,['#f0b76b','#e98e77','#dbe7d5'][i]);m.box(x,1.1,z,.04,.85,.04,'#f2e8ce');m.tri([x,1.51,z],[x,.89,z+.52],[x,.89,z],WHITE);}
      if(!light)for(let i=0;i<26;i++){const x=3.5+(i*1.7%3),z=-6.4+(i*1.37%12.8);m.box(x,.5,z,.24+(i%3)*.11,.012,.035,'#a2e5da');}
    }else if(night){
      m.box(0,.51,0,2,.08,13.2,'#294455');m.box(0,.51,0,13.2,.08,2,'#294455');
      for(let i=0;i<13;i++){m.box(0,.56,-6+i,.07,.015,.34,'#e3be79');m.box(-6+i,.56,0,.34,.015,.07,'#e3be79');}
      for(const x of [-5.5,-3.2,3.2,5.5])for(const z of [-5.3,-2.8,2.8,5.3]){const k=Math.round(Math.abs(x*11+z*7)),h=1+(k%5)*.37,c=['#79a8b0','#a9b8bc','#687fa5','#c5a38f'][k%4];m.box(x,.55+h/2,z,1.2,h,1.18,c,.055);m.box(x,.6+h,z,1.32,.12,1.3,'#d3d4be',.03);if(!light)for(let row=0;row<Math.floor(h/.32);row++)for(let col=0;col<3;col++){m.box(x-.36+col*.36,.8+row*.32,z+.6,.15,.17,.018,(row+col)%3?'#ffe1a0':'#9be7d6');m.box(x+.61,.8+row*.32,z-.35+col*.35,.018,.17,.15,'#b2e9dc');}}
      m.box(2.4,.89,0,1.8,.58,.62,'#eea470',.08);for(let i=0;i<4;i++)m.box(1.85+i*.36,1.02,.32,.22,.22,.02,'#274e64');for(const x of [-1.5,1.5])for(const z of [-4.7,-2.2,2.2,4.7])tree(m,x,z,.65);
    }else{
      m.box(0,.51,0,1.4,.04,13,'#b8d5d8');m.box(0,.51,2.5,12.5,.04,1.2,'#b8d5d8');
      for(let i=0;i<4;i++){const x=-5+i*3.1,z=-5.1+(i%2)*.3;m.cylinder(x,.5,z,1.8,2.8+i%2*.7,'#86acb7',0,5);m.cylinder(x,1.94+i%2*.35,z,.9,1.36+i%2*.35,'#f4f3e5',0,5);}
      for(const x of [-4.6,-2.4,2.4,4.8]){house(m,x,.2,1.65,'#bd7d68',true);house(m,x,4.7,1.3,'#bd7d68',true);tree(m,x+.9,3.5,.9,true);tree(m,x-.8,-1.5,.8,true);}
      m.box(0,.54,4.7,1.2,.06,1.4,'#a2c2d1');
    }
    return m;
  }
  function ownership(board,state,colors){
    const m=new Mesh();if(!state)return m;
    for(const t of board.tiles){const d=state.deeds[t.id];if(t.type!=='property'||d?.owner===null||d?.owner===undefined)continue;
      const c=V.cell(board.size,t.id),a=c.angle*Math.PI/180,xy=(dx,dy)=>world(c.cx+dx*Math.cos(a)-dy*Math.sin(a),c.cy+dx*Math.sin(a)+dy*Math.cos(a));
      const [x,z]=xy(-c.localWidth/2+8,-29),co=d.mortgaged?'#657581':colors[d.owner];
      m.cylinder(x,.43,z,.025,.83,'#e5c88c',.025,6);m.box(x+.2,.99,z,.4,.27,.055,co,.015);m.sphere(x,1.28,z,.055,.055,.055,'#f3d899',8);
      if(d.level){const [hx,hz]=xy(c.localWidth/2-14,-21);if(board.id==='metro'){m.box(hx,.45+d.level*.17,hz,.36,.34*d.level,.38,co,.025);m.box(hx,.48+d.level*.34,hz,.44,.09,.45,WHITE);}else house(m,hx,hz,.6,co,board.id==='alpine',d.level-1);}
    }
    return m;
  }
  function atlas(board,state,colors,light){
    const cvs=document.createElement('canvas');cvs.width=cvs.height=light?1024:2048;const ctx=cvs.getContext('2d');ctx.scale(cvs.width/640,cvs.height/640);
    const night=board.id==='metro';
    ctx.clearRect(0,0,640,640);
    for(const t of board.tiles){const c=V.cell(board.size,t.id),w=c.localWidth,d=state?.deeds[t.id],owner=d?.owner;ctx.save();ctx.translate(c.cx,c.cy);ctx.rotate(c.angle*Math.PI/180);
      ctx.fillStyle=night?'#e3ede8':'#fff5df';ctx.strokeStyle=night?'#78929a':'#b5c7b3';ctx.lineWidth=.85;ctx.fillRect(-w/2+1,-44,w-2,88);ctx.strokeRect(-w/2+1,-44,w-2,88);
      if(t.type==='property'){
        ctx.fillStyle=t.color;ctx.fillRect(-w/2+2,-43,w-4,13);
        ctx.fillStyle='#ffffffa6';ctx.fillRect(-w/2+3,-42,w-6,2);
        const words=t.name.split(' '),line1=words.slice(0,-1).join(' ')||words[0],line2=words.length>1?words.at(-1):'';
        ctx.textAlign='center';ctx.fillStyle='#233e49';ctx.font=`700 ${w<56?8:9}px -apple-system,Arial,sans-serif`;ctx.fillText(line1,0,-14,w-6);ctx.fillText(line2,0,-3,w-6);ctx.font='700 8px Arial';ctx.fillStyle='#53706e';ctx.fillText(t.price+' CR',0,10,w-6);
        if(owner!==undefined&&owner!==null){ctx.fillStyle=colors[owner];ctx.fillRect(-w/2+2,31,w-4,12);ctx.fillStyle='#172e3a';ctx.font='bold 7px Arial';ctx.fillText(d.mortgaged?'MORTGAGED':'P'+(owner+1),0,40,w-5);if(d.mortgaged){ctx.strokeStyle='#fff9';for(let k=-w/2;k<w/2;k+=6){ctx.beginPath();ctx.moveTo(k,31);ctx.lineTo(k+9,43);ctx.stroke();}}}
      }else{
        ctx.fillStyle={start:'#d7b15a',event:'#bd8ae2',fee:'#db8c78',rest:'#6ab9a1',detour:'#859bc6',dividend:'#e4b75c'}[t.type];ctx.beginPath();ctx.arc(0,-15,15,0,TAU);ctx.fill();ctx.fillStyle=WHITE;ctx.textAlign='center';ctx.font='bold 21px Arial';ctx.fillText({start:'↗',event:'?',fee:'−',rest:'Ⅱ',detour:'↪',dividend:'+'}[t.type],0,-8);
        ctx.fillStyle='#2b4954';ctx.font='bold 8px Arial';ctx.fillText(t.name.toUpperCase(),0,12,w-7);ctx.font='7px Arial';ctx.fillStyle='#637d7d';ctx.fillText({start:'+'+board.salary,event:'DISPATCH',fee:'−'+board.fee,rest:'REST STOP',detour:'SHORTCUT',dividend:'+100'}[t.type],0,23,w-6);
      }
      ctx.restore();
    }
    return cvs;
  }
  const VERTEX=`attribute vec3 aPosition;attribute vec3 aNormal;attribute vec3 aColor;attribute vec2 aUV;uniform mat4 uCamera;uniform vec4 uPose;uniform float uTurn;varying vec3 vNormal;varying vec3 vColor;varying vec2 vUV;void main(){float c=cos(uTurn),s=sin(uTurn);vec3 p=vec3(aPosition.x*c+aPosition.z*s,aPosition.y,-aPosition.x*s+aPosition.z*c);vNormal=vec3(aNormal.x*c+aNormal.z*s,aNormal.y,-aNormal.x*s+aNormal.z*c);vColor=aColor;vUV=aUV;gl_Position=uCamera*vec4(p*uPose.w+uPose.xyz,1.0);}`;
  const FRAGMENT=`precision mediump float;varying vec3 vNormal;varying vec3 vColor;varying vec2 vUV;uniform sampler2D uAtlas;uniform float uTextured;uniform float uUnlit;void main(){vec4 tex=texture2D(uAtlas,vUV);if(uTextured>.5&&tex.a<.1)discard;vec3 n=normalize(vNormal);float light=.48+.48*max(0.,dot(n,normalize(vec3(-.65,1.,.6))));float gloss=pow(max(0.,dot(n,normalize(vec3(-.25,1.,.8)))),18.)*.11;vec3 color=mix(vColor,tex.rgb,uTextured);gl_FragColor=vec4(color*mix(light,1.,uUnlit)+vec3(gloss)*(1.-uUnlit),1.);}`;
  class Renderer {
    constructor(){
      this.canvas=document.createElement('canvas');this.canvas.className='world-canvas';this.canvas.setAttribute('aria-label','Interactive 3D square board. Use All properties for an accessible list.');this.canvas.setAttribute('role','img');
      this.gl=this.canvas.getContext('webgl',{alpha:true,antialias:true,powerPreference:'low-power',preserveDrawingBuffer:false});if(!this.gl)throw Error('WebGL unavailable');
      this.resources=[];this.tokens=[];this.yaw=0;this.paused=false;this.lost=false;this.frame=0;this.initGL();
      this.canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();this.lost=true;cancelAnimationFrame(this.frame);this.host?.classList.remove('scene-ready');});
      this.canvas.addEventListener('webglcontextrestored',()=>{this.lost=false;this.key=null;this.resources=[];this.initGL();if(this.host)this.attach(this.host,this.options);});
      let down=null;
      this.canvas.addEventListener('pointerdown',e=>{down={x:e.clientX,y:e.clientY};});
      this.canvas.addEventListener('pointerup',e=>{if(!down||Math.hypot(e.clientX-down.x,e.clientY-down.y)>12){down=null;return;}down=null;const box=this.canvas.getBoundingClientRect(),id=pick(this.camera,e.clientX-box.left,e.clientY-box.top,box.width,box.height,this.options.board.size);if(id!==null)this.options.onTile(id);});
      if(typeof ResizeObserver!=='undefined')this.observer=new ResizeObserver(()=>this.resize());
    }
    initGL(){const gl=this.gl,compile=(type,src)=>{const s=gl.createShader(type);gl.shaderSource(s,src);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(s));return s;};const vs=compile(gl.VERTEX_SHADER,VERTEX),fs=compile(gl.FRAGMENT_SHADER,FRAGMENT);this.program=gl.createProgram();gl.attachShader(this.program,vs);gl.attachShader(this.program,fs);gl.linkProgram(this.program);gl.deleteShader(vs);gl.deleteShader(fs);if(!gl.getProgramParameter(this.program,gl.LINK_STATUS))throw Error('3D shader link failed');this.loc={};for(const a of ['aPosition','aNormal','aColor','aUV'])this.loc[a]=gl.getAttribLocation(this.program,a);for(const u of ['uCamera','uPose','uTurn','uAtlas','uTextured','uUnlit'])this.loc[u]=gl.getUniformLocation(this.program,u);gl.enable(gl.DEPTH_TEST);gl.depthFunc(gl.LEQUAL);}
    upload(mesh){const gl=this.gl,b=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,b);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(mesh.vertices),gl.STATIC_DRAW);const result={buffer:b,count:mesh.vertices.length/11};this.resources.push(b);return result;}
    attach(host,options){
      this.options=options;this.host=host;if(this.lost)return;host.appendChild(this.canvas);this.observer?.disconnect();this.observer?.observe(host);
      const key=options.board.id+':'+options.settings.graphics;
      if(this.key!==key){this.key=key;for(const b of this.resources)this.gl.deleteBuffer(b);this.resources=[];this.staticMesh=this.upload(scenery(options.board,options.settings.graphics==='light'));this.tokens=options.colors.map((co,id)=>this.upload(tokenMesh(id,co)));this.deedKey=null;this.ownerMesh=null;this.positions={};
        const plane=new Mesh();plane.quad([-10,.425,-10],[-10,.425,10],[10,.425,10],[10,.425,-10],WHITE,[[0,0],[0,1],[1,1],[1,0]]);this.plane=this.upload(plane);
      }
      const deeds=JSON.stringify(options.state?.deeds||{});
      if(this.deedKey!==deeds){this.deedKey=deeds;if(this.ownerMesh){this.gl.deleteBuffer(this.ownerMesh.buffer);this.resources=this.resources.filter(b=>b!==this.ownerMesh.buffer);}this.ownerMesh=this.upload(ownership(options.board,options.state,options.colors));this.updateTexture();}
      this.positions={};const players=options.players.filter(p=>!p.bankrupt);for(const p of players){const group=players.filter(q=>q.position===p.position);this.positions[p.id]=anchor(options.board.size,p.position,group.findIndex(q=>q.id===p.id),group.length);}
      this.move=null;this.paused=options.paused;host.classList.add('scene-ready');host.dataset.renderer='webgl';this.resize();
    }
    updateTexture(){const gl=this.gl;if(this.texture)gl.deleteTexture(this.texture);this.texture=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,this.texture);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,atlas(this.options.board,this.options.state,this.options.colors,this.options.settings.graphics==='light'));gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);}
    resize(){if(!this.host||this.lost)return;const rect=this.host.getBoundingClientRect();if(!rect.width||!rect.height)return;this.width=rect.width;this.height=rect.height;const dpr=Math.min(window.devicePixelRatio||1,this.options.settings.graphics==='light'?1:1.5);this.canvas.width=Math.round(rect.width*dpr);this.canvas.height=Math.round(rect.height*dpr);this.camera=camera(rect.width,rect.height,this.options.settings.camera,this.yaw);this.request();}
    rotate(delta){this.yaw+=delta;this.resize();}
    moveTo(id,position,duration){const target=anchor(this.options.board.size,position);this.move={id,from:this.positions[id],to:target,start:performance.now(),duration};this.request();}
    setPaused(paused){this.paused=paused;if(paused){cancelAnimationFrame(this.frame);this.frame=0;this.draw(performance.now());}else this.request();}
    request(){if(!this.frame&&!this.lost)this.frame=requestAnimationFrame(t=>{this.frame=0;this.draw(t);});}
    drawMesh(mesh,pose=[0,0,0,1],turn=0,textured=0,unlit=0){if(!mesh?.count)return;const gl=this.gl;gl.bindBuffer(gl.ARRAY_BUFFER,mesh.buffer);let offset=0;for(const [name,size] of [['aPosition',3],['aNormal',3],['aColor',3],['aUV',2]]){gl.enableVertexAttribArray(this.loc[name]);gl.vertexAttribPointer(this.loc[name],size,gl.FLOAT,false,44,offset*4);offset+=size;}gl.uniform4fv(this.loc.uPose,pose);gl.uniform1f(this.loc.uTurn,turn);gl.uniform1f(this.loc.uTextured,textured);gl.uniform1f(this.loc.uUnlit,unlit);gl.drawArrays(gl.TRIANGLES,0,mesh.count);}
    draw(now){
      if(!this.host?.isConnected||!this.camera||this.lost)return;const gl=this.gl;gl.viewport(0,0,this.canvas.width,this.canvas.height);gl.clearColor(0,0,0,0);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);gl.useProgram(this.program);gl.uniformMatrix4fv(this.loc.uCamera,false,this.camera.matrix);gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,this.texture);gl.uniform1i(this.loc.uAtlas,0);
      this.drawMesh(this.staticMesh);this.drawMesh(this.plane,undefined,0,1,1);this.drawMesh(this.ownerMesh);
      const animate=!this.paused&&this.options.settings.animations&&!window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
      for(const p of this.options.players.filter(p=>!p.bankrupt)){let a=this.positions[p.id],hop=0;if(this.move?.id===p.id){const t=Math.min(1,(now-this.move.start)/this.move.duration),ease=t*t*(3-2*t);a={x:this.move.from.x+(this.move.to.x-this.move.from.x)*ease,z:this.move.from.z+(this.move.to.z-this.move.from.z)*ease,scale:1.22};hop=animate?Math.sin(t*Math.PI)*.45:0;if(t===1){this.positions[p.id]=this.move.to;this.move=null;}}
        if(a)this.drawMesh(this.tokens[p.id],[a.x,.44+hop,a.z,a.scale],-.12+this.yaw);
      }
      // Render on demand; only token travel needs a frame loop. Stationary boards use no animation loop.
      if(this.move&&!this.paused)this.request();
    }
    detach(){cancelAnimationFrame(this.frame);this.frame=0;this.observer?.disconnect();this.canvas.remove();this.host=null;}
  }
  let instance=null,failed=false;
  function sync(host,options){if(!host){instance?.detach();return;}if(failed)return;try{if(!instance)instance=new Renderer();instance.attach(host,options);}catch(e){failed=true;instance?.detach();host.dataset.renderer='fallback';console.warn('Using illustrated board:',e.message);}}
  return {camera,project,pick,anchor,Mesh,scenery,tokenMesh,ownership,sync,moveTo:(...a)=>instance?.moveTo(...a),rotate:d=>instance?.rotate(d),pause:p=>instance?.setPaused(p),detach:()=>instance?.detach()};
});
