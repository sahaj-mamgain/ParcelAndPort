import SwiftUI
import WebKit
import UIKit

@main
struct ParcelAndPortApp: App {
    var body: some Scene {
        WindowGroup {
            GameView()
                .ignoresSafeArea()
                .preferredColorScheme(.light)
        }
    }
}

/// All game code and artwork ship inside the app. No remote content is loaded.
struct GameView: UIViewRepresentable {
    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> WKWebView {
        let controller = WKUserContentController()
        controller.add(context.coordinator, name: "parcelSave")
        controller.add(context.coordinator, name: "parcelHaptic")
        context.coordinator.installSavedState(in: controller)

        let configuration = WKWebViewConfiguration()
        configuration.userContentController = controller
        configuration.websiteDataStore = .default()
        let view = WKWebView(frame: .zero, configuration: configuration)
        view.navigationDelegate = context.coordinator
        view.isOpaque = false
        view.backgroundColor = UIColor(red: 245/255, green: 243/255, blue: 235/255, alpha: 1)
        view.scrollView.backgroundColor = view.backgroundColor
        view.scrollView.bounces = false
        view.scrollView.contentInsetAdjustmentBehavior = .never
        view.allowsBackForwardNavigationGestures = false

        if let url = Bundle.main.url(forResource: "index", withExtension: "html", subdirectory: "Web") {
            context.coordinator.webRoot = url.deletingLastPathComponent().standardizedFileURL
            view.loadFileURL(url, allowingReadAccessTo: url.deletingLastPathComponent())
        } else {
            view.loadHTMLString("<h1>Game resources are missing.</h1><p>Rebuild the app with the Web resource folder included.</p>", baseURL: nil)
        }
        return view
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}

    static func dismantleUIView(_ uiView: WKWebView, coordinator: Coordinator) {
        uiView.configuration.userContentController.removeScriptMessageHandler(forName: "parcelSave")
        uiView.configuration.userContentController.removeScriptMessageHandler(forName: "parcelHaptic")
        uiView.navigationDelegate = nil
    }

    final class Coordinator: NSObject, WKNavigationDelegate, WKScriptMessageHandler {
        private let saveKey = "parcel-and-port.save.v1"
        var webRoot: URL?

        func installSavedState(in controller: WKUserContentController) {
            controller.removeAllUserScripts()
            guard let save = UserDefaults.standard.string(forKey: saveKey),
                  let data = try? JSONSerialization.data(withJSONObject: [save]),
                  let encoded = String(data: data, encoding: .utf8) else { return }
            let script = WKUserScript(
                source: "window.__PARCEL_NATIVE_SAVE__ = \(encoded)[0];",
                injectionTime: .atDocumentStart,
                forMainFrameOnly: true
            )
            controller.addUserScript(script)
        }

        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            if message.name == "parcelHaptic", message.frameInfo.isMainFrame {
                guard let kind = message.body as? String else { return }
                if kind == "success" {
                    UINotificationFeedbackGenerator().notificationOccurred(.success)
                } else if kind == "light" {
                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                }
                return
            }
            guard message.name == "parcelSave", message.frameInfo.isMainFrame,
                  let value = message.body as? String, value.utf8.count <= 500_000,
                  let bytes = value.data(using: .utf8),
                  let payload = try? JSONSerialization.jsonObject(with: bytes) as? [String: Any],
                  payload["version"] as? Int == 1 else {
                message.webView?.evaluateJavaScript("window.dispatchEvent(new Event('parcel-save-error'))", completionHandler: nil)
                return
            }
            // App-owned backup survives changes to the bundled file URL during app updates.
            UserDefaults.standard.set(value, forKey: saveKey)
            installSavedState(in: userContentController)
        }

        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            guard let url = navigationAction.request.url, url.isFileURL,
                  let root = webRoot,
                  url.standardizedFileURL.path.hasPrefix(root.path + "/") else {
                decisionHandler(.cancel)
                return
            }
            decisionHandler(.allow)
        }

        func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
            installSavedState(in: webView.configuration.userContentController)
            webView.reload()
        }
    }
}
