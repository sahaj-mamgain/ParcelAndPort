const {test}=require('node:test');
const assert=require('node:assert/strict');
const E=require('../ios/ParcelAndPort/Web/engine.js');
const V=require('../ios/ParcelAndPort/Web/visuals.js');
const S=require('../ios/ParcelAndPort/Web/scene3d.js');
test('all tile centers round-trip through every 3D camera and board rotation',()=>{
  for(const b of E.BOARDS)for(const mode of ['angled','top','follow'])for(const yaw of [0,Math.PI/2,Math.PI,Math.PI*1.5])for(const [w,h] of [[1000,580],[756,650],[390,340]]){
    const camera=S.camera(w,h,mode,yaw);
    for(const t of b.tiles){const c=V.cell(b.size,t.id),p=S.project(camera,[(c.cx-320)/32,.425,(c.cy-320)/32],w,h);assert.equal(S.pick(camera,p.x,p.y,w,h,b.size),t.id);assert(p.x>0&&p.x<w&&p.y>0&&p.y<h);}
    assert.equal(S.pick(camera,w/2,h/2,w,h,b.size),null);
  }
});
test('eight 3D anchors stay distinct and on their square in every world',()=>{
  for(const b of E.BOARDS)for(const t of b.tiles){const c=V.cell(b.size,t.id),seen=new Set();for(let i=0;i<8;i++){const p=S.anchor(b.size,t.id,i,8),x=p.x*32+320,z=p.z*32+320;assert(x>=c.x&&x<=c.x+c.w&&z>=c.y&&z<=c.y+c.h);seen.add(p.x+','+p.z);}assert.equal(seen.size,8);}
});
test('original 3D worlds and all eight models have finite bounded mesh data',()=>{
  for(const mesh of [...E.BOARDS.flatMap(b=>[S.scenery(b),S.scenery(b,true)]),...E.PLAYER_COLORS.map((co,id)=>S.tokenMesh(id,co))]){assert(mesh.vertices.length>1000);assert.equal(mesh.vertices.length%33,0);assert(mesh.vertices.every(Number.isFinite));assert(mesh.vertices.length/11<100000,'Geometry must fit older iPads');}
  for(const b of E.BOARDS)assert(S.scenery(b,true).vertices.length<=S.scenery(b).vertices.length);
});
test('buying, trading and mortgaging update ownership geometry without changing rules state',()=>{
  let s=E.createGame({seed:10});s.phase='offer';s.players[0].position=1;
  assert.equal(S.ownership(E.board(s),s,E.PLAYER_COLORS).vertices.length,0);
  s=E.act(s,{type:'buy'});const before=E.serialize(s),owned=S.ownership(E.board(s),s,E.PLAYER_COLORS);assert(owned.vertices.length>100);assert.equal(E.serialize(s),before);
  s=E.act(s,{type:'propose',target:1,giveIds:[1]});s=E.act(s,{type:'accept'});const traded=S.ownership(E.board(s),s,E.PLAYER_COLORS);assert.notDeepEqual(traded.vertices,owned.vertices);
  s.current=1;s.phase='roll';s=E.act(s,{type:'mortgage',id:1});assert.notDeepEqual(S.ownership(E.board(s),s,E.PLAYER_COLORS).vertices,traded.vertices);
});
