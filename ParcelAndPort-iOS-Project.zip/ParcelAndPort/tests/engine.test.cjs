const {test}=require('node:test');
const assert=require('node:assert/strict');
const E=require('../ios/ParcelAndPort/Web/engine.js');
const newGame=(extra={})=>E.createGame({seed:123,players:[{name:'A',ai:'human'},{name:'B',ai:'human'},{name:'C',ai:'human'}],...extra});
function offer(s,id=1){s.players[s.current].position=id;s.phase='offer';return s;}
function own(s,ids,owner=0){for(const id of ids)s.deeds[id].owner=owner;return s;}
function debt(s,amount,creditor=null){s.phase='debt';s.debt={amount,creditor,reason:'test payment'};return s;}
test('three distinct boards have unique names, complete districts and all special stop types',()=>{
  assert.deepEqual(E.BOARDS.map(b=>b.size),[24,32,40]);
  for(const b of E.BOARDS){assert.equal(b.tiles.length,b.size);assert.equal(new Set(b.names).size,b.names.length);for(let group=0;group<b.districts.length;group++)assert.equal(b.tiles.filter(t=>t.group===group).length,3);for(const type of ['start','event','fee','rest','detour'])assert(b.tiles.some(t=>t.type===type));}
});
test('supports two to eight seats and independent AI styles',()=>{
  for(let n=2;n<=8;n++){const s=newGame({players:Array.from({length:n},(_,i)=>({name:'Seat '+i,ai:['human','relaxed','balanced','bold'][i%4]}))});assert.equal(s.players.length,n);E.validate(s);}
  assert.throws(()=>newGame({players:[{name:'Only'}]}));assert.throws(()=>newGame({players:Array(9).fill({name:'Extra'})}));assert.throws(()=>newGame({roundLimit:-1}));
});
test('actions are transactional and seeded dice are reproducible',()=>{
  const s=newGame(),before=E.serialize(s);const a=E.act(s,{type:'roll'}),b=E.act(E.restore(before),{type:'roll'});assert.deepEqual(a,b);assert.equal(E.serialize(s),before);assert.throws(()=>E.act(s,{type:'buy'}));assert.equal(E.serialize(s),before);assert.equal(a.dice.length,2);
});
test('passing Home Port pays the salary and resolves landing',()=>{
  const s=newGame();s.players[0].position=23;const a=E.act(s,{type:'roll'});assert.equal(a.players[0].position,(23+a.lastRoll)%24);assert(a.players[0].cash>=s.players[0].cash+200-90);E.validate(a);
});
test('buying deducts cash, assigns ownership and completes the turn',()=>{
  const s=offer(newGame());const t=E.property(s,1),a=E.act(s,{type:'buy'});assert.equal(a.deeds[1].owner,0);assert.equal(a.players[0].cash,s.players[0].cash-t.price);assert.equal(a.phase,'end');assert.throws(()=>E.act(a,{type:'buy'}));
});
test('insufficient purchase cash does not mutate state',()=>{
  const s=offer(newGame());s.players[0].cash=0;assert.throws(()=>E.act(s,{type:'buy'}));assert.equal(s.deeds[1].owner,null);assert.equal(s.phase,'offer');
});
test('declining a property opens an auction that permits the declining player',()=>{
  let s=E.act(offer(newGame()),{type:'auction'});assert.equal(s.auction.bidder,0);s=E.act(s,{type:'bid',amount:10});assert.equal(s.auction.bidder,1);s=E.act(s,{type:'pass'});assert.equal(s.auction.bidder,2);s=E.act(s,{type:'pass'});assert.equal(s.phase,'end');assert.equal(s.deeds[1].owner,0);assert.equal(s.players[0].cash,1390);
});
test('auction outbidding rotates correctly and only the winner pays',()=>{
  let s=E.act(offer(newGame()),{type:'auction'});s=E.act(s,{type:'bid',amount:40});s=E.act(s,{type:'bid',amount:80});s=E.act(s,{type:'pass'});assert.equal(s.auction.bidder,0);s=E.act(s,{type:'pass'});assert.equal(s.deeds[1].owner,1);assert.equal(s.players[0].cash,1400);assert.equal(s.players[1].cash,1320);
});
test('all auction passes leave the property unowned',()=>{
  let s=E.act(offer(newGame()),{type:'auction'});for(let i=0;i<3;i++)s=E.act(s,{type:'pass'});assert.equal(s.phase,'end');assert.equal(s.deeds[1].owner,null);
});
test('zero-cash and sole-affordable-bidder auctions terminate',()=>{
  let s=offer(newGame());s.players.forEach(p=>p.cash=0);s=E.act(s,{type:'auction'});assert.equal(s.phase,'end');
  s=offer(newGame());s.players[1].cash=0;s.players[2].cash=5;s=E.act(s,{type:'auction'});assert.equal(s.auction.bidder,0);s=E.act(s,{type:'bid',amount:10});assert.equal(s.phase,'end');assert.equal(s.deeds[1].owner,0);
});
test('invalid bids leave the state unchanged',()=>{
  const s=E.act(offer(newGame()),{type:'auction'}),before=E.serialize(s);for(const amount of [-1,0,9,10.5,1401,NaN])assert.throws(()=>E.act(s,{type:'bid',amount}));assert.equal(E.serialize(s),before);
});
test('district bonus and upgrade rents follow the published table',()=>{
  let s=own(newGame(),[1,2,3]);assert.equal(E.rent(s,1),24);s=E.act(s,{type:'build',id:1});assert.equal(E.rent(s,1),48);assert.throws(()=>E.act(s,{type:'build',id:1}));for(const id of [2,3,1])s=E.act(s,{type:'build',id});assert.equal(E.rent(s,1),108);E.validate(s);
});
test('building requires the whole district and enforces balanced selling',()=>{
  let s=own(newGame(),[1]);assert.throws(()=>E.act(s,{type:'build',id:1}));own(s,[2,3]);s=E.act(s,{type:'build',id:1});s=E.act(s,{type:'build',id:2});s=E.act(s,{type:'build',id:3});s=E.act(s,{type:'build',id:1});assert.throws(()=>E.act(s,{type:'sell',id:2}));const cash=s.players[0].cash;s=E.act(s,{type:'sell',id:1});assert.equal(s.players[0].cash,cash+30);assert.equal(s.deeds[1].level,1);
});
test('mortgaging pauses rent and district bonus; redemption charges 10 percent',()=>{
  let s=own(newGame(),[1,2,3]);const cash=s.players[0].cash;s=E.act(s,{type:'mortgage',id:1});assert.equal(s.players[0].cash,cash+50);assert.equal(E.rent(s,1),0);assert.equal(E.rent(s,2),15);assert.throws(()=>E.act(s,{type:'build',id:2}));assert.throws(()=>E.act(s,{type:'mortgage',id:1}));s=E.act(s,{type:'redeem',id:1});assert.equal(s.players[0].cash,cash-5);assert.equal(E.rent(s,1),24);
});
test('upgraded districts cannot be mortgaged or traded',()=>{
  let s=own(newGame(),[1,2,3]);s=E.act(s,{type:'build',id:1});assert.throws(()=>E.act(s,{type:'mortgage',id:2}));assert.equal(E.tradeable(s,2,0),false);assert.throws(()=>E.act(s,{type:'propose',target:1,giveIds:[2],takeIds:[],giveCash:0,takeCash:100}));
});
test('debt can be paid after selling and mortgaging without premature transfers',()=>{
  let s=own(newGame(),[1,2,3]);s.players[0].cash=20;debt(s,90,1);const creditorCash=s.players[1].cash;assert.throws(()=>E.act(s,{type:'settle'}));s=E.act(s,{type:'mortgage',id:1});assert.equal(s.phase,'debt');assert.equal(s.players[1].cash,creditorCash);s=E.act(s,{type:'mortgage',id:2});s=E.act(s,{type:'settle'});assert.equal(s.phase,'end');assert.equal(s.players[0].cash,40);assert.equal(s.players[1].cash,creditorCash+90);
});
test('conceding to a player transfers cash and mortgaged deeds',()=>{
  let s=own(newGame(),[1]);s=E.act(s,{type:'mortgage',id:1});s.players[0].cash=30;debt(s,400,1);s=E.act(s,{type:'concede'});assert.equal(s.players[0].bankrupt,true);assert.equal(s.players[0].cash,0);assert.equal(s.players[1].cash,1430);assert.equal(s.deeds[1].owner,1);assert.equal(s.deeds[1].mortgaged,true);s=E.act(s,{type:'end'});assert.equal(s.current,1);E.validate(s);
});
test('conceding to the city clears the deeds and detects last standing',()=>{
  let s=own(newGame({players:[{name:'A'},{name:'B'}]}),[1,2,3]);s=E.act(s,{type:'build',id:1});s.players[0].cash=0;debt(s,400);s=E.act(s,{type:'concede'});assert.deepEqual(s.deeds[1],{owner:null,level:0,mortgaged:false});assert.equal(s.phase,'finished');assert.deepEqual(s.winners,[1]);E.validate(s);
});
test('trade acceptance moves exactly the offered cash and deeds',()=>{
  let s=own(newGame(),[1]);own(s,[5],1);s=E.act(s,{type:'propose',target:1,giveCash:75,takeCash:20,giveIds:[1],takeIds:[5]});assert.equal(s.phase,'trade');assert.equal(E.decisionPlayer(s).id,1);assert.equal(s.deeds[1].owner,0);s=E.act(s,{type:'accept'});assert.equal(s.phase,'roll');assert.equal(s.players[0].cash,1345);assert.equal(s.players[1].cash,1455);assert.equal(s.deeds[1].owner,1);assert.equal(s.deeds[5].owner,0);E.validate(s);
});
test('trade rejection changes no balances or properties',()=>{
  let s=own(newGame(),[1]);s=E.act(s,{type:'propose',target:1,giveIds:[1],takeIds:[],giveCash:0,takeCash:200});s=E.act(s,{type:'reject'});assert.equal(s.players[0].cash,1400);assert.equal(s.players[1].cash,1400);assert.equal(s.deeds[1].owner,0);assert.equal(s.phase,'roll');
});
test('invalid, repeated, unaffordable and out-of-phase trades are rejected',()=>{
  const s=own(newGame(),[1]);for(const args of [{target:0,giveCash:2},{target:1,giveCash:-1},{target:1,giveCash:2000},{target:1,giveIds:[1,1]},{target:1,giveIds:[5]},{target:1}])assert.throws(()=>E.act(s,{type:'propose',...args}));s.phase='offer';assert.throws(()=>E.act(s,{type:'propose',target:1,giveCash:20}));
});
test('delay allows waiting or paying once, then rolling',()=>{
  let s=newGame();s.players[0].skipTurns=1;let waited=E.act(s,{type:'roll'});assert.equal(waited.phase,'end');assert.equal(waited.players[0].skipTurns,0);assert.equal(waited.players[0].position,0);
  s=E.act(s,{type:'leave'});assert.equal(s.players[0].cash,1340);assert.equal(s.phase,'roll');assert.throws(()=>E.act(s,{type:'leave'}));s=E.act(s,{type:'roll'});assert.equal(s.dice.length,2);
});
test('rounds wrap past eliminated seats and timed matches rank wealth, including ties',()=>{
  let s=newGame({roundLimit:12});s.round=12;s.current=2;s.phase='end';s.players[0].cash=1800;s.players[1].cash=1800;s.players[2].cash=1500;s=E.act(s,{type:'end'});assert.equal(s.phase,'finished');assert.deepEqual(s.winners,[0,1]);
  s=newGame();s.players[0].bankrupt=true;s.players[0].cash=0;s.current=2;s.phase='end';s=E.act(s,{type:'end'});assert.equal(s.current,1);assert.equal(s.round,2);
});
test('wealth accounts for loans without double-counting cash',()=>{
  let s=own(newGame(),[1]);const before=E.wealth(s,0);s=E.act(s,{type:'mortgage',id:1});assert.equal(E.wealth(s,0),before);s=E.act(s,{type:'redeem',id:1});assert.equal(E.wealth(s,0),before-5);
});
test('AI initiates district-completing trades and rejects exploitative offers',()=>{
  let s=newGame({players:[{name:'A',ai:'bold'},{name:'B',ai:'balanced'},{name:'C',ai:'human'}]});own(s,[1,2]);own(s,[3],1);s.phase='end';const a=E.botAction(s);assert.equal(a.type,'propose');assert.deepEqual(a.takeIds,[3]);s=E.act(s,a);assert.equal(E.botAction(s).type,'accept');s=E.act(s,E.botAction(s));assert(E.ownsGroup(s,0,0));assert.equal(E.botAction(s).type,'build');
  s=newGame({players:[{name:'A',ai:'human'},{name:'B',ai:'bold'}]});own(s,[1,2,3],1);s=E.act(s,{type:'propose',target:1,takeIds:[1],giveCash:1});assert.equal(E.botAction(s).type,'reject');
});
test('saved games round-trip during an auction, debt and pending trade',()=>{
  const cases=[E.act(offer(newGame()),{type:'auction'}),debt(newGame(),500),E.act(own(newGame(),[1]),{type:'propose',target:1,giveIds:[1],takeCash:100})];
  for(const s of cases)assert.deepEqual(E.restore(E.serialize(s)),s);
});
test('corrupt and unsupported saves are rejected',()=>{
  assert.throws(()=>E.restore('{'));assert.throws(()=>E.restore('x'.repeat(500001)));
  for(const corrupt of [s=>s.version=999,s=>s.players[0].cash=-1,s=>s.current=10,s=>s.deeds[1].owner=99,s=>s.deeds[1].level=2,s=>s.phase='auction',s=>s.phase='debt',s=>s.deck=[1,1],s=>s.players[0].name='<'.repeat(25)]){const s=newGame();corrupt(s);assert.throws(()=>E.restore(JSON.stringify(s)));}
});
test('landing on another player’s property pays rent once or creates a debt',()=>{
  let s=own(newGame({seed:1}),[5],1);const cash=s.players[0].cash;
  let a=E.act(s,{type:'roll'});assert.equal(a.players[0].position,5);assert.equal(a.players[0].cash,cash-17);assert.equal(a.players[1].cash,1417);assert.equal(a.phase,'end');
  s.players[0].cash=2;a=E.act(s,{type:'roll'});assert.equal(a.phase,'debt');assert.equal(a.debt.amount,17);assert.equal(a.debt.creditor,1);assert.equal(a.players[1].cash,1400);
});
test('every dispatch card resolves and the ten-card deck is consumed',()=>{
  for(let card=0;card<10;card++){
    const s=newGame({seed:10});s.deck=[card];const a=E.act(s,{type:'roll'});assert.equal(a.lastRoll,4);assert.equal(a.deck.length,0);assert(a.lastEvent.title);E.validate(a);
    if(card===0)assert.equal(a.players[0].cash,1520);
    if(card===1)assert.equal(a.players[0].cash,1320);
    if(card===2){assert.equal(a.players[0].position,7);assert.equal(a.phase,'offer');}
    if(card===3){assert.equal(a.players[0].position,2);assert.equal(a.phase,'offer');}
    if(card===4){assert.equal(a.players[0].position,0);assert.equal(a.players[0].cash,1600);}
    if(card===5)assert.equal(a.players[0].cash,1490);
    if(card===6)assert.equal(a.players[0].cash,1400);
    if(card===7)assert.equal(a.players[0].cash,1460);
    if(card===8){assert.equal(a.players[0].position,12);assert.equal(a.players[0].skipTurns,1);assert.equal(a.players[0].cash,1400);}
    if(card===9)assert.equal(a.players[0].cash,1440);
  }
});
test('dispatch upkeep counts properties and upgrade tiers',()=>{
  let s=own(newGame({seed:10}),[1,2,3]);s=E.act(s,{type:'build',id:1});s.deck=[6];const before=s.players[0].cash;s=E.act(s,{type:'roll'});assert.equal(s.players[0].cash,before-105);assert.equal(s.phase,'end');
});
test('normal Breather, Detour and levy landings have different effects',()=>{
  let s=newGame({seed:1});s.players[0].position=7;let a=E.act(s,{type:'roll'});assert.equal(a.players[0].position,12);assert.equal(a.players[0].cash,1440);assert.equal(a.players[0].skipTurns,0);
  s.players[0].position=15;a=E.act(s,{type:'roll'});assert.equal(a.players[0].position,12);assert.equal(a.players[0].cash,1400);assert.equal(a.players[0].skipTurns,1);
  s.players[0].position=3;a=E.act(s,{type:'roll'});assert.equal(a.players[0].cash,1310);assert.equal(a.phase,'end');
});
