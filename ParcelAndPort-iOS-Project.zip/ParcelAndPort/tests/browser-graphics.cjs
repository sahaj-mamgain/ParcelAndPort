/* Run on CI with Playwright installed. Screenshots come from the actual app. */
const {chromium,webkit}=require('playwright');
const http=require('node:http'),fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const E=require('../ios/ParcelAndPort/Web/engine.js');
const web=path.resolve(__dirname,'../ios/ParcelAndPort/Web'),out=path.resolve(__dirname,'../graphics-report');fs.mkdirSync(out,{recursive:true});
const names=['Sahaj','Mira','Cleo','Jules','Ari','Niko','Remy','Tess'];
function fixture(boardId,count=8){const s=E.createGame({boardId,seed:10,players:names.slice(0,count).map(name=>({name,ai:'human'}))});s.players.forEach((p,i)=>{p.position=Math.floor(i*E.board(s).size/count);});for(const t of E.board(s).tiles)if(t.type==='property'&&t.id!==1)s.deeds[t.id].owner=t.id%count;s.players[0].position=1;s.phase='offer';return E.serialize(s);}
const server=http.createServer((req,res)=>{const file=path.join(web,decodeURIComponent(req.url.split('?')[0]==='/'?'/index.html':req.url.split('?')[0]));if(!file.startsWith(web+path.sep)){res.writeHead(403).end();return;}fs.readFile(file,(err,data)=>{if(err){res.writeHead(404).end();return;}res.setHeader('Content-Type',({'.html':'text/html','.js':'application/javascript','.css':'text/css','.png':'image/png'})[path.extname(file)]||'application/octet-stream');res.end(data);});});
(async()=>{
  await new Promise(resolve=>server.listen(8765,'127.0.0.1',resolve));const browsers=[];const summary=[];
  try{
    const browser=await chromium.launch({headless:true,args:['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});browsers.push(browser);
    const page=await browser.newPage({viewport:{width:1024,height:768},deviceScaleFactor:1});const errors=[];page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
    await page.route('**/*',route=>route.request().url().startsWith('http://127.0.0.1:8765/')?route.continue():route.abort());
    async function load(board,count=8,graphics='balanced'){
      await page.goto('http://127.0.0.1:8765/');await page.evaluate(({save,graphics})=>{localStorage.setItem('parcel-and-port.save.v1',save);localStorage.setItem('parcel-and-port.settings.v2',JSON.stringify({graphics,animations:false}));},{save:fixture(board,count),graphics});await page.reload();await page.getByRole('button',{name:'Continue game',exact:true}).click();await page.getByRole('button',{name:/I’m ready/}).click();
      await page.locator('.corner-player').last().waitFor();if(graphics!=='illustrated')await page.locator('.scene-ready').waitFor();await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
    }
    for(const board of ['harbor','metro','alpine']){
      await load(board);assert.equal(await page.locator('.corner-player').count(),8);assert.equal(await page.locator('canvas.world-canvas').count(),1);
      const fit=await page.evaluate(()=>{const nodes=[...document.querySelectorAll('.corner-player,.action-dock')];return nodes.every(n=>{const r=n.getBoundingClientRect();return r.x>=0&&r.y>=0&&r.right<=innerWidth+.1&&r.bottom<=innerHeight+.1;})&&document.documentElement.scrollWidth<=innerWidth;});assert(fit,board+' landscape controls must fit');
      await page.screenshot({path:path.join(out,board+'-landscape.png')});
      await page.locator('[data-action="buy"]').click();assert.equal(await page.evaluate(()=>JSON.parse(localStorage.getItem('parcel-and-port.save.v1')).deeds[1].owner),0);assert.match(await page.locator('.scene-fallback [data-id="1"]').getAttribute('aria-label'),/owned by Sahaj/);
      await page.locator('[data-camera="top"].camera-btn').click();await page.screenshot({path:path.join(out,board+'-top.png')});
      const tap=await page.evaluate(()=>{const h=document.getElementById('scene-host'),r=h.getBoundingClientRect(),b=Parcel.board(JSON.parse(localStorage.getItem('parcel-and-port.save.v1'))),c=ParcelVisuals.cell(b.size,1),p=Parcel3D.project(Parcel3D.camera(r.width,r.height,'top'),[(c.cx-320)/32,.425,(c.cy-320)/32],r.width,r.height);return {x:r.x+p.x,y:r.y+p.y};});await page.mouse.click(tap.x,tap.y);await page.locator('dialog[open]').waitFor();assert.match(await page.locator('dialog').textContent(),new RegExp(E.BOARDS.find(b=>b.id===board).tiles[1].name));await page.locator('dialog [data-action="close"]').first().click();
      summary.push(board+': WebGL, 8 corner cards, buy/ownership and 3D tile picking passed');
    }
    for(const size of [{width:768,height:1024},{width:390,height:844}]){
      await page.setViewportSize(size);await load('harbor');await page.screenshot({path:path.join(out,size.width===768?'ipad-portrait.png':'phone-portrait.png')});assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
      const buttons=await page.locator('.corner-player').evaluateAll(ns=>ns.map(n=>{const r=n.getBoundingClientRect();return {x:r.x,y:r.y,w:r.width,h:r.height};}));assert(buttons.every(r=>r.x>=0&&r.y>=0&&r.x+r.w<=size.width&&r.y+r.h<=size.height));summary.push(size.width+'px portrait: 8 corner cards fit');
    }
    await page.setViewportSize({width:1024,height:768});await load('harbor',8,'light');await page.screenshot({path:path.join(out,'light-mode.png')});
    await page.locator('[data-action="buy"]').click();await page.locator('[data-action="end"]').click();await page.getByRole('button',{name:/I’m ready/}).click();await page.locator('[data-action="menu"]').first().click();await page.locator('#animation-setting').selectOption('on');await page.locator('dialog [data-action="close"]').first().click();await page.locator('[data-action="roll"]').click();const committed=await page.evaluate(()=>localStorage.getItem('parcel-and-port.save.v1'));await page.locator('[data-action="skip-motion"]').click();assert.equal(await page.evaluate(()=>localStorage.getItem('parcel-and-port.save.v1')),committed);summary.push('Light mode and committed roll/skip passed');
    await load('alpine',8,'illustrated');await page.screenshot({path:path.join(out,'illustrated-fallback.png')});assert.equal(await page.locator('canvas.world-canvas').count(),0);await page.locator('[data-action="all-properties"]').click();await page.locator('dialog[open]').waitFor();summary.push('Illustrated compatibility mode and accessible property list passed');
    assert.deepEqual(errors,[]);summary.push('No browser JavaScript errors; all app requests confined to local origin');
    // WebKit also exercises the actual DOM/actions used by the iOS wrapper.
    const wk=await webkit.launch({headless:true});browsers.push(wk);const wp=await wk.newPage({viewport:{width:1024,height:768}});const wkErrors=[];wp.on('pageerror',e=>wkErrors.push(e.message));await wp.goto('http://127.0.0.1:8765/');await wp.evaluate(save=>localStorage.setItem('parcel-and-port.save.v1',save),fixture('harbor'));await wp.reload();await wp.getByRole('button',{name:'Continue game',exact:true}).click();await wp.getByRole('button',{name:/I’m ready/}).click();await wp.locator('[data-action="buy"]').click();assert.equal(await wp.evaluate(()=>JSON.parse(localStorage.getItem('parcel-and-port.save.v1')).deeds[1].owner),0);await wp.screenshot({path:path.join(out,'webkit.png')});assert.deepEqual(wkErrors,[]);summary.push('WebKit: eight-player resume and property purchase passed; renderer '+await wp.locator('#scene-host').getAttribute('data-renderer'));
    fs.writeFileSync(path.join(out,'results.json'),JSON.stringify({passed:true,checks:summary},null,2));console.log(summary.join('\n'));
  }catch(e){fs.writeFileSync(path.join(out,'failure.txt'),e.stack);throw e;}finally{for(const b of browsers)await b.close();server.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
