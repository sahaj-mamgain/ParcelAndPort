# Validation record — 3D square-board update (v1.2)

Local checks: 56 tests pass, including all prior 52 and four new 3D checks. The 3D checks cover every tile under three cameras and four rotations at three viewport sizes, eight distinct anchors on all spaces, finite geometry with a vertex budget, and ownership geometry after buying/trading/mortgaging.

CI browser suite: Chromium WebGL rendering, all three boards, 1024×768 landscape, 768×1024 and 390×844 portrait, eight corner HUDs, real board tapping, buy/ownership updates, light mode, skipping a committed roll, illustrated fallback and WebKit purchase/resume. Screenshots and a results JSON are uploaded as `ParcelAndPort-Graphics`. These checks are included and awaiting their first CI run for v1.2; successful results will be recorded after the run.

The earlier v1.1 native build succeeded on GitHub Actions (run 43733242434), producing an arm64 device IPA with iOS 16 minimum. Archive CRCs and every bundled web resource were checked. The v1.2 native build is pending. Neither version has been installed or performance-tested on the physical iPad in this session.

## Baseline gameplay verification (engine unchanged)

## Passed

- **31 rules tests:** seat limits, all three boards, deterministic rolls, purchases, landing rent, every Dispatch card, salaries, levies, detours, auctions, evenly built/sold upgrades, mortgage arithmetic, debt, elimination, trades, AI valuation, round endings, ties, and save validation.
- **15 application-logic tests:** eight-seat setup, board selection, escaping player names, handoff state, replacement-save confirmation, auction and trade decisions, mortgage controls, pausing AI, unavailable storage, native-bridge save messages, committing a roll once before animation, skipping safely, backgrounding during a move, Reduce Motion, and camera preference persistence. These run the app code with a lightweight DOM/event harness; they are not real-browser layout tests.
- **6 presentation tests:** all three perimeter layouts are square and nonoverlapping, all spaces can hold eight distinct piece anchors, animated routes match dice and event outcomes, waiting turns have no fake movement, eight player illustrations are defined, and dice have six faces with the settled orientation.
- **225 baseline deterministic full-match simulations (unchanged rules engine):** 25 seeds × 3 boards × 3 player counts (2, 4, 8), with 24-round limits and mixed AI personalities. Every match finished. There were **66,493 actions, 245 proposed trades, and 23 eliminations**. Save/restore round-trips were exercised during simulations, and state invariants were checked after every action.
- JavaScript syntax checks.
- Swift source syntax parsing with the available Swift compiler. This does not type-check UIKit/SwiftUI against an iOS SDK.
- Xcode project and Info/Privacy plist syntax validation.
- Shell script syntax checks; missing-SDK preflight reports the real blocker and creates no IPA.
- Local-only resource inspection: no remote scripts/fonts, game network calls, or third-party board-game branding in bundled runtime files.
- Standalone HTML preview generated from the exact bundled CSS and JavaScript, with the generated scene atlas embedded once as a data URI. No network asset requests are required.

## Still requires a physical device

- iOS installation/signing and launch, WebGL performance and memory pressure on the fifth-generation iPad.
- Native save persistence across force quits/app upgrades, haptics and sound.
- VoiceOver and large accessibility text, safe areas on each target device.
- Open-ended matches can run indefinitely with passive players; timed matches are covered by the baseline simulations.

## Commands

```bash
node --test tests/*.test.cjs
node tests/stress.cjs
python3 scripts/package-preview.py
bash scripts/build-ipa.sh --unsigned
```

## First-device acceptance pass

After building, run on an iPhone and iPad in portrait and landscape. Check Tabletop, Top-down, and Follow views; dice tumbling and every space hop; skipping and backgrounding mid-animation; generated illustration loading in airplane mode; sound after enabling it; native haptics on supported hardware; and system Reduce Motion. Start eight local seats on each board; try a mixed human/AI match; buy and auction a property; complete a trade; manage upgrades and mortgages; trigger a debt and elimination; close/reopen the app during a handoff, auction, and trade; confirm airplane-mode play and restoration. Check large text, screen safe areas, VoiceOver labels, and the 40-stop board's readable property ledger. Verify an IPA signed for the intended device installs and launches.
