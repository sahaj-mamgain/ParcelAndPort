# Parcel & Port — Illustrated Tabletop Edition

An original offline property trading game for iPhone and iPad. It uses its own name, square boards, place names, interface, event cards, and geometric artwork. No third-party board-game branding or artwork is included.

## What is included

- **Square boards with camera controls:** an angled Tabletop view, readable Top-down view, and Follow view that pans toward the active piece.
- **Original illustrations throughout:** three painted worlds, eight distinct player pieces, miniature property buildings, illustrated property cards, event art, and a celebration scene.
- **Animated play:** six-face tumbling dice, step-by-step piece hops, event shortcuts, purchase/upgrade celebrations, credit changes, card reveals, and victory effects.
- **Sound and feedback:** optional synthesized dice, step, purchase, and upgrade sounds; native light/success haptics on supported hardware. Sound starts off.
- **Motion controls:** skip a move's animation, select Cinematic or Quick movement, disable movement animations, and honor system Reduce Motion. A roll commits and saves once before presentation starts; skipping, changing camera, or backgrounding cannot reroll it.

- **2–8 total seats:** any mix of people and AI, including eight human players or an all-AI spectator game.
- **One-device pass-and-play:** handoff prompts identify whose turn, bid, or trade decision comes next. There is no Wi-Fi, Bluetooth, LAN, or online multiplayer.
- **Three boards:** Harbor Hop (24 stops / 6 districts), Midnight Metro (32 / 8), Alpine Trails (40 / 10). Each has different properties, starting budgets, salaries, and levies.
- **Three AI personalities:** Relaxed, Balanced, and Bold. They roll, buy, bid, upgrade, manage debt, evaluate trades, and, for Balanced/Bold, offer trades to complete districts.
- **Property trading:** purchases, open auctions, rent, district bonuses, three evenly built upgrade tiers, mortgages, redemptions, cash/property trades, elimination, and final standings.
- **Match lengths:** 12, 18, 24, or 36 rounds, or last player standing. Open-ended games can run a long time; a round limit is the default.
- **Offline saves:** after every decision. The iOS app keeps an app-owned backup in addition to WebKit local storage. Resume from setup. Starting a new game asks before replacing the existing save.
- **No runtime dependencies:** no accounts, ads, remote fonts, analytics, payments, or network requests. All currency is fictional game credits.

## Build status — read this first

**This package contains the game source, a standalone playable HTML preview, and an Xcode project. It does not contain a compiled IPA.**

The development Mac had Apple Command Line Tools, but no full Xcode installation or iOS SDK. The native source was syntax-checked and the project/plists were parsed, but the app has **not been compiled, run in an iOS simulator, or tested on an iPhone/iPad**. Visual browser testing remains unverified: local-file navigation was blocked earlier, and the preview browser connection was unavailable during the presentation update. The JavaScript rules and AI were tested independently; see `VALIDATION.md` for exact results.

## Play the desktop preview

Open **`ParcelAndPort-Play.html`** in Safari or Chrome on your Mac. It is a complete, self-contained copy of the same game shipped inside the app and requires no server or internet connection. Keep the file at the same path so browser-local saves remain associated with it. Browser privacy settings may prevent file-based storage; the game will show an autosave warning if it cannot save.

This file is a desktop preview, not an iOS installer. iOS Files/Quick Look may not run an interactive HTML document. Use the native app for installed offline iPhone/iPad play.

For local development with an HTTP origin:

```bash
bash scripts/preview.sh
```

Open `http://127.0.0.1:8765` on the same Mac. This helper serves only on the loopback interface; it does not publish the game or enable network multiplayer.

## Build an unsigned IPA on a Mac

1. Install full Xcode from Apple, open it once, and install iOS platform support.
2. From this folder, run:

```bash
bash scripts/build-ipa.sh --unsigned
```

The output is `build/ParcelAndPort-unsigned.ipa`. It is an actual iOS app archive compiled for devices, but it must be signed with your own signing credentials before it can be installed on a standard iPhone/iPad. Use your chosen signing/sideloading tool; the unsigned build needs no Apple credentials during compilation. No IPA is created if Xcode or the SDK is missing.

You can also build without installing Xcode locally: put the **contents of this folder at the root of a GitHub repository**, open its **Actions** tab, run **Build unsigned iOS app**, and download the **ParcelAndPort-unsigned** artifact. The included workflow uses a hosted macOS runner. It has not been run as part of this delivery. Extract the downloaded artifact to obtain the unsigned IPA, then sign it yourself.

## Run directly from Xcode

1. Open `ios/ParcelAndPort.xcodeproj`.
2. Select the **ParcelAndPort** target → **Signing & Capabilities**.
3. Select your Apple team and change `local.parcelandport.game` to a bundle identifier available to you.
4. Choose a connected iPhone/iPad or an installed iOS simulator and press Run.

The project targets **iOS/iPadOS 16.0 or newer**, supports iPhone/iPad and portrait/landscape, and uses SwiftUI with a WKWebView that loads only bundled files. It has no package-manager or third-party native dependencies.

## Export a signed IPA

After Xcode has your Apple account and appropriate signing assets/provisioning for the intended devices:

```bash
bash scripts/build-ipa.sh --signed YOURTEAMID com.yourname.parcelandport
```

`YOURTEAMID` is your own 10-character Apple Team ID. The script archives the app, uses automatic signing, and exports to `build/signed/`. Its default Xcode export method is `debugging`. You may select `EXPORT_METHOD=release-testing` when your account and provisioning support that distribution method. Account eligibility, registered devices, and provisioning still determine whether export/install succeeds.

For a GUI export, select a generic iOS device destination, choose **Product → Archive**, then use the Archives organizer's distribution/export flow. Apple documents registered-device distribution here:

- https://developer.apple.com/documentation/xcode/distributing-your-app-to-registered-devices
- https://developer.apple.com/documentation/xcode/distributing-your-app-for-beta-testing-and-releases

## Presentation reference

The repository at https://github.com/charlie2099/Monopoly-Clone was inspected as a visual reference. Its demo and camera controller show a raised square board, board-centered dice, and front/top-down/follow views. This update implements those presentation ideas independently in the existing game; no code, branded board textures, or other assets from that repository were imported.

Rendering uses SVG, CSS perspective, six-face CSS dice, and original generated artwork. The camera controls tilt or pan this board presentation; dice outcomes come from the tested rules engine. It is not a Unity engine port or a rigid-body dice physics simulation.

The app-owned save format remains version 1, so saved games from the previous circular presentation can continue on the square layout. The app version is now 1.1 (build 2). The original gameplay rules and board tile order are preserved.

## Rules and deliberate differences

The in-game **How to play** dialog is the complete rules reference. This is an independently designed property trading game, not a reproduction of another game's board or exact rule set.

Both dice move the player; doubles do not grant an extra turn. Each district has exactly three properties. Completing an unmortgaged district doubles base rent; upgrade tiers charge 4×, 9×, and 16× base rent. Build evenly. Selling reverses that process at half construction cost. Mortgage value is half the property price. Redemption is principal plus 10%, rounded up to a whole credit.

Declined properties enter an auction with a 10-credit minimum opening bid and increases of at least 10. Passing removes a player from that auction. A normal Breather landing grants 40 credits; Detours and planning-delay cards instead require waiting out the next roll or paying 60 to leave. Dispatch cards form a shuffled deck that refills after ten draws.

Trades are available before rolling or after a turn's landing has been resolved. Both players must agree; upgraded districts cannot be traded until all upgrades are sold. Mortgages travel with their deeds without a separate transfer fee. Debt is resolved through existing cash, selling upgrades, mortgaging, or conceding. There is no trading during debt collection.

In timed games, wealth is cash + purchase prices + full upgrade costs − mortgage principal. Eliminated players cannot win; tied active leaders share the win. Conceding to a player passes cash and deeds to them. Conceding to the city clears the deeds and returns them to the market.

## Source and verification

```bash
node --test tests/engine.test.cjs tests/ui-logic.test.cjs tests/visuals.test.cjs
node tests/stress.cjs
python3 scripts/package-preview.py
```

- `ios/ParcelAndPort/Web/engine.js`: deterministic rules and AI, usable in Node or WebKit.
- `ios/ParcelAndPort/Web/app.js`: setup, board, trade dialogs, handoff prompts, and saving.
- `ios/ParcelAndPort/Web/style.css` and `deluxe.css`: responsive interface, perspective cameras, CSS dice, and animation styles.
- `ios/ParcelAndPort/Web/visuals.js`: tested square geometry, move paths, original player pieces, and property illustrations.
- `ios/ParcelAndPort/Web/assets/worlds.png`: the original four-scene image atlas, generated for this project; all imagery is bundled offline.
- `ios/ParcelAndPort/ParcelAndPortApp.swift`: native entry point, bundled web view, navigation policy, and app-owned save backup.
- `scripts/make-icon.py`: reproducible original app icon; generated icons are already included.
- `scripts/build-ipa.sh`: unsigned packaging or signed archive/export.
- `tests/`: rule assertions and deterministic multi-board AI simulations.

Names/artwork were created for this project; no comprehensive trademark clearance search was performed. This source may be customized for personal use. The Apple SDK, signing, and distribution tools remain governed by their respective providers.
