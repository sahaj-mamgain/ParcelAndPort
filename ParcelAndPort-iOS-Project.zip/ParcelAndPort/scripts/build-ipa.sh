#!/bin/bash
set -euo pipefail
project_dir="$(cd "$(dirname "$0")/.." && pwd)"
mode="${1:---unsigned}"
if [[ "$mode" != "--unsigned" && "$mode" != "--signed" ]]; then
  echo "Usage: $0 --unsigned | --signed TEAM_ID [BUNDLE_ID]"
  exit 2
fi
if [[ -z "${DEVELOPER_DIR:-}" && -d /Applications/Xcode.app/Contents/Developer ]]; then
  export DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer
fi
if ! xcrun --sdk iphoneos --show-sdk-path >/dev/null 2>&1; then
  echo "Cannot build an IPA: full Xcode and the iOS SDK are required."
  echo "Install Xcode, open it once to install iOS support, then run this script again."
  echo "Command Line Tools alone are not sufficient. No IPA has been produced."
  exit 1
fi
build_dir="$project_dir/build"
mkdir -p "$build_dir"
if [[ "$mode" == "--unsigned" ]]; then
  xcodebuild -project "$project_dir/ios/ParcelAndPort.xcodeproj" \
    -scheme ParcelAndPort -configuration Release -sdk iphoneos \
    -destination 'generic/platform=iOS' -derivedDataPath "$build_dir/DerivedData" \
    CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO build
  payload_dir="$(mktemp -d "$build_dir/payload.XXXXXX")"
  trap 'rm -rf "$payload_dir"' EXIT
  mkdir -p "$payload_dir/Payload"
  ditto "$build_dir/DerivedData/Build/Products/Release-iphoneos/ParcelAndPort.app" "$payload_dir/Payload/ParcelAndPort.app"
  ditto -c -k --keepParent "$payload_dir/Payload" "$build_dir/ParcelAndPort-unsigned.ipa"
  echo "Created $build_dir/ParcelAndPort-unsigned.ipa"
  echo "This is unsigned. Sign it with your own credentials before installation."
else
  team_id="${2:-}"
  bundle_id="${3:-local.parcelandport.game}"
  export_method="${EXPORT_METHOD:-debugging}"
  if [[ ! "$team_id" =~ ^[A-Za-z0-9]{10}$ || ! "$bundle_id" =~ ^[A-Za-z0-9.-]+$ ]]; then
    echo "Provide your 10-character Apple Team ID and a valid bundle identifier."
    exit 2
  fi
  case "$export_method" in debugging|release-testing|development|ad-hoc) ;; *) echo "Unsupported EXPORT_METHOD."; exit 2;; esac
  cat > "$build_dir/ExportOptions.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<plist version="1.0"><dict>
<key>method</key><string>$export_method</string>
<key>teamID</key><string>$team_id</string>
<key>signingStyle</key><string>automatic</string>
<key>destination</key><string>export</string>
<key>stripSwiftSymbols</key><true/>
</dict></plist>
PLIST
  xcodebuild -project "$project_dir/ios/ParcelAndPort.xcodeproj" -scheme ParcelAndPort \
    -configuration Release -destination 'generic/platform=iOS' \
    -archivePath "$build_dir/ParcelAndPort.xcarchive" -derivedDataPath "$build_dir/DerivedData" \
    -allowProvisioningUpdates DEVELOPMENT_TEAM="$team_id" PRODUCT_BUNDLE_IDENTIFIER="$bundle_id" archive
  xcodebuild -exportArchive -archivePath "$build_dir/ParcelAndPort.xcarchive" \
    -exportPath "$build_dir/signed" -exportOptionsPlist "$build_dir/ExportOptions.plist" -allowProvisioningUpdates
  echo "Signed export is in $build_dir/signed"
fi
