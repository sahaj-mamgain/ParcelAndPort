const assert=require('node:assert/strict');
const E=require('../ios/ParcelAndPort/Web/engine.js');
let games=0,actions=0,trades=0,eliminations=0;
for(const b of E.BOARDS)for(const count of [2,4,8])for(let seed=1;seed<=25;seed++){
  let s=E.createGame({boardId:b.id,seed,roundLimit:24,players:Array.from({length:count},(_,i)=>({name:`Player ${i+1}`,ai:['relaxed','balanced','bold'][i%3]}))});
  let steps=0;
  while(s.phase!=='finished'&&steps<15000){
    const a=E.botAction(s);assert(a,`No AI action: ${b.id}, seed ${seed}, phase ${s.phase}`);
    if(a.type==='propose')trades++;if(a.type==='concede')eliminations++;
    s=E.act(s,a);E.validate(s);steps++;
    if(steps%37===0)s=E.restore(E.serialize(s));
  }
  assert.equal(s.phase,'finished',`Stalled: ${b.id}, ${count} seats, seed ${seed}`);assert(s.winners.length>=1);actions+=steps;games++;
}
console.log(JSON.stringify({games,actions,trades,eliminations,allFinished:true},null,2));
