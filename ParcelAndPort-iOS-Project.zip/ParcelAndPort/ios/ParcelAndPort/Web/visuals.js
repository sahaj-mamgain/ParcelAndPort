/* Original presentation primitives. Board geometry is independent of the rules. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.ParcelVisuals=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';
  const SIZE=640,EDGE=90;
  const TOKEN_NAMES=['Sailboat','Balloon','Rocket','Fox','Lantern','Robot','Pine','Compass'];
  function cell(size,id){
    if(!Number.isInteger(size)||size<8||size%4||!Number.isInteger(id)||id<0||id>=size)throw Error('Invalid square-board location.');
    const side=size/4,step=(SIZE-2*EDGE)/(side-1),quarter=Math.floor(id/side),within=id%side;
    let x,y,w,h;
    if(within===0){w=h=EDGE;[x,y]=[[SIZE-EDGE,SIZE-EDGE],[0,SIZE-EDGE],[0,0],[SIZE-EDGE,0]][quarter];}
    else if(quarter===0){x=SIZE-EDGE-within*step;y=SIZE-EDGE;w=step;h=EDGE;}
    else if(quarter===1){x=0;y=SIZE-EDGE-within*step;w=EDGE;h=step;}
    else if(quarter===2){x=EDGE+(within-1)*step;y=0;w=step;h=EDGE;}
    else{x=SIZE-EDGE;y=EDGE+(within-1)*step;w=EDGE;h=step;}
    return {x,y,w,h,cx:x+w/2,cy:y+h/2,angle:quarter*90,corner:within===0,localWidth:within===0?EDGE:step};
  }
  function tokenPoint(size,position,slot=0,count=1){
    const c=cell(size,position),columns=count>1?2:1,rows=Math.ceil(count/columns);
    const dx=((slot%columns)-(columns-1)/2)*17,dy=22+(Math.floor(slot/columns)-(rows-1)/2)*14,r=c.angle*Math.PI/180;
    return {x:c.cx+dx*Math.cos(r)-dy*Math.sin(r),y:c.cy+dx*Math.sin(r)+dy*Math.cos(r)};
  }
  function movement(before,after){
    const p=before.players[before.current],end=after.players[p.id],size=before.boardId==='harbor'?24:before.boardId==='metro'?32:40;
    if(p.skipTurns||!after.dice.length)return [];
    const trail=[];let position=p.position;
    for(let i=0;i<after.lastRoll;i++){position=(position+1)%size;trail.push({position,teleport:false});}
    if(position!==end.position){
      const title=after.lastEvent?.title;
      if(title==='A useful shortcut'||title==='Scenic route'){
        const direction=title==='Scenic route'?-1:1;
        const count=title==='Scenic route'?2:3;
        for(let i=0;i<count;i++){position=(position+direction+size)%size;trail.push({position,teleport:false});}
      }
      if(position!==end.position)trail.push({position:end.position,teleport:true});
    }
    return trail;
  }
  function token(id,color='#ef7759'){
    const base=`<ellipse cx="40" cy="69" rx="26" ry="8" fill="#132c35" opacity=".2"/><ellipse cx="40" cy="65" rx="25" ry="8" fill="${color}"/><ellipse cx="40" cy="62" rx="25" ry="7" fill="#fff4d5" stroke="${color}" stroke-width="3"/>`;
    const art=[
      `<path d="M18 49H65L56 61H28Z" fill="${color}" stroke="#643f32" stroke-width="2"/><path d="M40 14V50" stroke="#8d6240" stroke-width="3"/><path d="M37 17L18 44H37Z" fill="#fff5cf"/><path d="M44 21L60 44H44Z" fill="${color}"/><path d="M21 51L58 51" stroke="#fff3cf" stroke-width="2"/>`,
      `<path d="M27 43L33 58M53 43L47 58" stroke="#bb8b58" stroke-width="2"/><ellipse cx="40" cy="27" rx="22" ry="25" fill="${color}"/><ellipse cx="40" cy="27" rx="10" ry="25" fill="#fff0c1"/><path d="M31 55H49L47 65H34Z" fill="#b97c44"/><path d="M25 17Q31 9 36 9" stroke="#ffffff" stroke-width="3" fill="none" opacity=".7"/>`,
      `<path d="M31 46L25 60L34 56M49 46L56 60L46 56" fill="${color}"/><path d="M34 56L40 69L46 56" fill="#efba5b"/><path d="M40 8Q62 30 47 56H33Q18 30 40 8Z" fill="#e8f0ed" stroke="#8aa2a2" stroke-width="2"/><path d="M30 23L40 8L50 23Z" fill="${color}"/><circle cx="40" cy="35" r="8" fill="#24536b" stroke="${color}" stroke-width="3"/><circle cx="37" cy="32" r="2" fill="#c3f2f5"/>`,
      `<path d="M25 47Q8 45 17 60Q24 67 39 59" fill="${color}"/><path d="M28 37Q17 65 40 65Q61 65 51 37" fill="${color}"/><path d="M22 17L23 39L40 49L58 37L58 16L45 25H35Z" fill="${color}" stroke="#9c6943" stroke-width="1.5"/><path d="M23 35L40 49L57 35L45 39H35Z" fill="#fff2d6"/><path d="M27 24L29 31L34 28M53 24L51 31L46 28" fill="#614a45"/><circle cx="32" cy="35" r="2" fill="#273746"/><circle cx="48" cy="35" r="2" fill="#273746"/><path d="M37 41H43L40 45Z" fill="#273746"/>`,
      `<path d="M29 19Q29 5 40 5Q51 5 51 19" stroke="#ceab5f" stroke-width="5" fill="none"/><path d="M24 21H56L60 59H20Z" fill="${color}"/><rect x="27" y="28" width="26" height="25" rx="3" fill="#ffde84"/><path d="M40 32Q30 47 40 51Q51 47 40 32" fill="#fff6cc"/><path d="M22 20H58M19 61H61" stroke="#c2a261" stroke-width="5"/>`,
      `<path d="M28 55L25 65M52 55L55 65M22 41L14 50M58 41L66 50" stroke="${color}" stroke-width="7" stroke-linecap="round"/><rect x="24" y="34" width="32" height="26" rx="7" fill="${color}"/><path d="M40 18V9" stroke="#b9c6c5" stroke-width="3"/><circle cx="40" cy="7" r="4" fill="${color}"/><rect x="20" y="18" width="40" height="26" rx="8" fill="#e7eeed" stroke="#9bacad" stroke-width="2"/><rect x="27" y="25" width="26" height="10" rx="4" fill="#203c4a"/><circle cx="33" cy="30" r="2" fill="#a2ebdb"/><circle cx="47" cy="30" r="2" fill="#a2ebdb"/><circle cx="40" cy="50" r="4" fill="#ffe6a3"/>`,
      `<path d="M36 53H44V66H36Z" fill="#b58452"/><path d="M40 8L19 35H29L13 53H67L51 35H61Z" fill="${color}" stroke="#426d53" stroke-width="2"/><path d="M40 8L31 28L40 25L34 44L40 41" fill="#fff3c6" opacity=".65"/><circle cx="29" cy="45" r="3" fill="#efbd60"/><circle cx="48" cy="30" r="3" fill="#edaa70"/>`,
      `<circle cx="40" cy="34" r="27" fill="#d5ad5f"/><circle cx="40" cy="34" r="22" fill="#fff2d2" stroke="#926e42" stroke-width="2"/><path d="M40 13L46 34L40 55L34 34Z" fill="${color}"/><path d="M19 34L40 29L61 34L40 39Z" fill="#809ca6"/><circle cx="40" cy="34" r="4" fill="#dfb569"/><path d="M26 17Q33 11 41 12" fill="none" stroke="#fff7dc" stroke-width="3"/>`
    ][id%8];
    return `<svg viewBox="0 0 80 80" aria-hidden="true" class="token-art">${base}${art}</svg>`;
  }
  function building(boardId,id,accent='#70a99a',level=0){
    const n=id%3,h=level*5,roof=accent;
    let art='';
    if(boardId==='metro'){
      const left=23+n*4,high=16-h;
      art=`<path d="M16 65L43 76L89 56L62 47Z" fill="#c9d8d3"/><path d="M${left} 20L48 ${high}L48 65L${left} 72Z" fill="${roof}"/><path d="M48 ${high}L69 ${high+9}V73L48 65Z" fill="#3e6471"/><path d="M${left} 20L45 ${high-7}L69 ${high+9}L48 ${high}Z" fill="#aacbd0"/><path d="M59 39L79 30L79 64L59 72Z" fill="#d4cba8"/><path d="M79 30L90 36V68L79 64Z" fill="#9caaab"/>`;
      for(let row=0;row<4+level;row++)for(let col=0;col<2;col++)art+=`<path d="M${left+4+col*9} ${26+row*7-h}l5 -2v4l-5 2Z" fill="${row%2?'#a6e5dd':'#ffe5a1'}"/>`;
      art+='<path d="M51 23l5 2v29l-5 -2Z" fill="#a0cbd0" opacity=".6"/>';
    }else{
      const alpine=boardId==='alpine',peak=alpine?13-h:20-h,wall=alpine?'#ead4a4':'#f8e7b9';
      art=`<ellipse cx="50" cy="69" rx="39" ry="10" fill="#355748" opacity=".13"/><path d="M26 40L55 28L76 40V65L48 78L26 65Z" fill="${wall}"/><path d="M48 47L76 40V65L48 78Z" fill="#c4b48f"/><path d="M19 42L40 ${peak}L64 ${peak+9}L53 52Z" fill="${roof}"/><path d="M40 ${peak}L64 ${peak+9}L83 40L53 52Z" fill="${alpine?'#a76555':'#b56e51'}"/><path d="M19 42L40 ${peak}L53 52" stroke="#fff2cf" stroke-width="2" fill="none"/><path d="M35 56L43 60V73L35 69Z" fill="#426c68"/><path d="M57 53l10 -4v11l-10 4Z" fill="#4f8991"/><path d="M58 54l8 -3M62 52v10" stroke="#f8e7b9" stroke-width="1.5"/><path d="M29 48l7 3v6l-7 -3Z" fill="#719ca0"/>`;
      if(alpine)art+='<path d="M12 37L2 56H8L0 68H24L17 56H23Z" fill="#54866b"/><path d="M11 65H15V75H11Z" fill="#906a48"/>';
      else art+='<path d="M84 48L82 70" stroke="#ad8a5c" stroke-width="3"/><path d="M84 49Q67 32 73 48Q80 40 84 49Q95 29 96 47Q90 42 84 49Q101 49 96 58Q90 48 84 49" fill="#629b77"/>';
      if(level>0)art+=`<path d="M59 ${peak+3}V${peak-7}L66 ${peak-10}V${peak+5}Z" fill="#dcb97d"/>`;
    }
    return `<svg viewBox="0 0 100 84" class="building-art" aria-hidden="true">${art}</svg>`;
  }
  function special(type){
    const icons={
      start:'<path d="M15 45L40 24L65 45V67H17Z" fill="#e8cc86"/><path d="M10 45L40 17L70 45" fill="none" stroke="#315c62" stroke-width="7" stroke-linejoin="round"/><path d="M33 66V48H48V66" fill="#568a82"/><path d="M23 29V17H31V24" fill="#cf9770"/>',
      event:'<path d="M14 24H66V64H14Z" fill="#e4c47c" stroke="#9b8053" stroke-width="2"/><path d="M14 27L40 47L66 27" fill="#fff1cc"/><path d="M14 64L34 45M66 64L47 45" stroke="#bb995e" stroke-width="2"/><path d="M36 6L40 17L51 21L40 25L36 36L32 25L21 21L32 17Z" fill="#fff6cb" stroke="#cba65f"/>',
      fee:'<ellipse cx="32" cy="58" rx="23" ry="10" fill="#c69543"/><path d="M9 48V58Q32 71 55 58V48" fill="#c99e50"/><ellipse cx="32" cy="48" rx="23" ry="10" fill="#f0d18a"/><ellipse cx="48" cy="32" rx="22" ry="10" fill="#ecc97d"/><path d="M26 22V32Q48 45 70 32V22" fill="#bc9450"/><ellipse cx="48" cy="22" rx="22" ry="10" fill="#f8df9c"/><path d="M42 21H54" stroke="#b58c48" stroke-width="3"/>',
      rest:'<circle cx="58" cy="22" r="13" fill="#e7bb62"/><path d="M15 27L30 51H64M21 39H53L64 51M30 51L24 69M58 51L65 69" fill="none" stroke="#6c9888" stroke-width="6" stroke-linecap="round"/><path d="M13 24L22 37" stroke="#f2dfb2" stroke-width="8" stroke-linecap="round"/>',
      detour:'<path d="M11 66L40 10L69 66Z" fill="#e7af62" stroke="#bd7950" stroke-width="3" stroke-linejoin="round"/><path d="M33 50V35H51M45 28L53 35L45 42" fill="none" stroke="#4b5550" stroke-width="6" stroke-linejoin="round"/><path d="M12 69H68" stroke="#615f54" stroke-width="5"/>',
      dividend:'<path d="M15 31H65V68H15Z" fill="#8bb8a1"/><path d="M11 27H69V38H11Z" fill="#4b8e7c"/><path d="M35 27H46V68H35Z" fill="#efcc85"/><path d="M40 28Q16 29 22 14Q27 2 40 28Q54 1 61 14Q67 29 40 28" fill="none" stroke="#d5a85c" stroke-width="6"/>'
    };
    return `<svg viewBox="0 0 80 80" class="special-art" aria-hidden="true">${icons[type]||icons.event}</svg>`;
  }
  function die(value){
    const dots={1:[4],2:[0,8],3:[0,4,8],4:[0,2,6,8],5:[0,2,4,6,8],6:[0,2,3,5,6,8]},rotation={1:[0,0],2:[0,-90],3:[-90,0],4:[90,0],5:[0,90],6:[0,180]}[value];
    return `<div class="die-toss"><div class="die-tilt"><div class="die-cube" style="--die-x:${rotation[0]}deg;--die-y:${rotation[1]}deg">${[1,2,3,4,5,6].map(n=>`<span class="die-face face-${n}" aria-hidden="true">${Array.from({length:9},(_,i)=>`<i class="${dots[n].includes(i)?'':'blank'}"></i>`).join('')}</span>`).join('')}</div></div></div>`;
  }
  return {SIZE,EDGE,TOKEN_NAMES,cell,tokenPoint,movement,token,building,special,die};
});
