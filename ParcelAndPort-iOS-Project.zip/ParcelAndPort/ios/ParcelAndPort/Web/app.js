(function () {
  'use strict';
  const E=window.Parcel,V=window.ParcelVisuals,root=document.getElementById('app'),dialog=document.getElementById('modal');
  const SAVE_KEY='parcel-and-port.save.v1',SETTINGS_KEY='parcel-and-port.settings.v2';
  let settings={camera:'angled',sound:false,animations:true,tempo:'normal'};
  try{const value=JSON.parse(localStorage.getItem(SETTINGS_KEY)||'{}');if(['angled','top','follow'].includes(value.camera))settings.camera=value.camera;if(typeof value.sound==='boolean')settings.sound=value.sound;if(typeof value.animations==='boolean')settings.animations=value.animations;if(['normal','quick'].includes(value.tempo))settings.tempo=value.tempo;}catch{}
  let motion=null,movementTimers=[],effect=null,effectTimer=null,audioContext=null;
  const names=['You','Mira','Cleo','Jules','Ari','Niko','Remy','Tess'];
  let setup={boardId:'harbor',roundLimit:18,players:[{name:'You',ai:'human'},{name:'Mira',ai:'human'},{name:'Cleo',ai:'balanced'},{name:'Jules',ai:'balanced'}]};
  let game=null,saved=null,modalState=null,botTimer=null,toastTimer=null,fastAI=false,saveWarning='',loadWarning='';
  const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const credits=n=>Math.round(n).toLocaleString('en-US');
  const color=id=>E.PLAYER_COLORS[id];
  const pawn=p=>`<span class="pawn illustrated-pawn" style="--player-color:${color(p.id)}" aria-hidden="true">${V.token(p.id,color(p.id))}<b>${p.id+1}</b></span>`;
  const button=(label,action,cls='primary',attrs='')=>`<button class="${cls}" data-action="${action}" ${attrs}>${label}</button>`;
  const labelAI=type=>({human:'Local player',relaxed:'Relaxed AI',balanced:'Balanced AI',bold:'Bold AI'}[type]);
  try {let raw=window.__PARCEL_NATIVE_SAVE__;if(!raw)raw=localStorage.getItem(SAVE_KEY);if(raw)saved=E.restore(raw);}catch(e){loadWarning='The previous save could not be read. You can start a new match.';}
  function save() {
    if(!game)return;
    try {
      const data=E.serialize(game);saved=E.restore(data);let stored=false;
      try{localStorage.setItem(SAVE_KEY,data);stored=true;}catch{}
      if(window.webkit?.messageHandlers?.parcelSave){window.webkit.messageHandlers.parcelSave.postMessage(data);stored=true;}
      saveWarning=stored?'':'Autosave is unavailable in this browser. Keep this window open to keep playing.';
    }catch(e){saveWarning='Autosave failed: '+e.message;}
  }
  function toast(text) {const el=document.getElementById('toast');el.textContent=text;el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),4200);}
  function header(inGame=false) {return `<header class="topbar"><button class="brand" data-action="${inGame?'menu':'home'}" aria-label="Parcel and Port ${inGame?'game menu':'home'}"><span class="brand-mark">p.</span><span><span class="brand-name">parcel &amp; port</span><span class="brand-caption" style="display:block">A LITTLE EMPIRE, TOGETHER.</span></span></button><nav class="nav" aria-label="Main"><span class="online-badge"><span class="status-dot"></span> ALL TOGETHER. ALL OFFLINE.</span>${button(settings.sound?'♪':'♫','sound','icon-btn sound-toggle',`aria-label="${settings.sound?'Mute':'Enable'} sound effects" aria-pressed="${settings.sound}"`)}${button('How to play','help','text-btn')}${inGame?button('Ⅱ','menu','icon-btn','aria-label="Pause and open menu"'):''}</nav></header>`;}
  function boardSVG(b,s) {
    const segments=b.tiles.map(t=>{
      const c=V.cell(b.size,t.id),w=c.localWidth,h=V.EDGE,d=s?.deeds[t.id],owner=d?.owner;
      const selected=s&&E.current(s).position===t.id;
      const words=t.name.split(' '),first=words.slice(0,-1).join(' ')||words[0],second=words.length>1?words.at(-1):'';
      const available=owner===null||owner===undefined;
      const picture=t.type==='property'?V.building(b.id,t.id,t.color,d?.level||0):V.special(t.type);
      const face=t.type==='property'?'#fff8e5':t.type==='start'?'#f1cf86':'#e3eddf';
      return `<g class="tile ${selected?'tile-active':''} ${c.corner?'corner-tile':''}" role="button" tabindex="0" data-action="tile" data-id="${t.id}" aria-label="${esc(t.name)}${t.type==='property'?`, price ${t.price}, ${available?'available':'owned by '+esc(s.players[owner].name)}`:''}"><title>${esc(t.name)}</title><g transform="translate(${c.cx} ${c.cy}) rotate(${c.angle})"><rect x="${-w/2+1}" y="${-h/2+1}" width="${w-2}" height="${h-2}" rx="2" fill="${face}" stroke="${selected?'#e5ac48':'#b8b9a3'}" stroke-width="${selected?3:1}"/>${t.type==='property'?`<rect x="${-w/2+2}" y="${-h/2+2}" width="${w-4}" height="11" fill="${t.color}"/>`:''}<svg x="${-Math.min(w-8,56)/2}" y="${t.type==='property'?-32:-34}" width="${Math.min(w-8,56)}" height="${t.type==='property'?34:41}" viewBox="${t.type==='property'?'0 0 100 84':'0 0 80 80'}">${picture.replace(/^<svg[^>]*>/,'').replace(/<\/svg>$/,'')}</svg><text text-anchor="middle" font-size="${w<55?8:9}" font-weight="700" fill="#25483d"><tspan x="0" y="11">${esc(first)}</tspan><tspan x="0" y="22">${esc(second)}</tspan></text><text x="0" y="35" text-anchor="middle" font-size="8" font-weight="600" fill="#607466">${t.type==='property'?(d?.mortgaged?'MORTGAGED':`${credits(t.price)} CR`):({start:'COLLECT '+b.salary,event:'DRAW A CARD',fee:'PAY '+b.fee,rest:'TAKE A BREAK',detour:'CHANGE ROUTE',dividend:'COLLECT 100'}[t.type])}</text>${!available?`<rect x="${-w/2+2}" y="39" width="${w-4}" height="4" fill="${color(owner)}"/>`:''}${d?.level?`<g transform="translate(${-w/2+5} -41)">${Array.from({length:d.level},(_,i)=>`<path d="M${i*10} 5V0L${i*10+4} -3L${i*10+8} 0V5Z" fill="#fff4cf" stroke="#617d5d" stroke-width=".7"/>`).join('')}</g>`:''}</g></g>`;
    }).join('');
    return `<svg class="board-svg" viewBox="0 0 640 640" role="group" aria-label="Square ${esc(b.name)} board, ${b.size} stops. Select a property for details."><rect x="1" y="1" width="638" height="638" rx="5" fill="none" stroke="#d4b46b" stroke-width="2"/><rect x="91" y="91" width="458" height="458" fill="none" stroke="#bca35e" stroke-width="3"/>${segments}</svg>`;
  }
  function diceHTML(dice,rolling=false) {
    return `<div class="dice dice-3d ${rolling?'dice-rolling':''}" aria-label="${rolling?'Dice rolling':dice.length?'Rolled '+dice.join(' and '):'Ready to roll'}">${(dice.length?dice:[1,1]).map(n=>V.die(n)).join('')}</div>`;
  }
  function tokenLayer(b,s) {
    const players=s?s.players.filter(p=>!p.bankrupt):setup.players.map((p,id)=>({...p,id,position:id===0?0:(id*3+1)%b.size}));
    return `<div class="token-layer" aria-hidden="true">${players.map(p=>{
      const together=players.filter(x=>x.position===p.position),slot=together.findIndex(x=>x.id===p.id),point=V.tokenPoint(b.size,p.position,slot,together.length);
      return `<div class="board-token ${s&&p.id===s.current?'current-token':''}" id="board-token-${p.id}" style="left:${point.x/6.4}%;top:${point.y/6.4}%;--player-color:${color(p.id)}"><span class="token-shadow"></span><span class="token-piece">${V.token(p.id,color(p.id))}</span><b>${p.id+1}</b></div>`;
    }).join('')}</div>`;
  }
  function cameraStyle(b,s) {
    if(!s)return '--focus-x:0%;--focus-y:0%;';
    const p=E.current(s),point=V.cell(b.size,p.position);
    return `--focus-x:${(320-point.cx)/640*100}%;--focus-y:${(320-point.cy)/640*100}%;`;
  }
  function effectHTML(){
    if(!effect)return '';
    return `<div class="action-effect effect-${effect.tone}" role="status"><span class="effect-medallion">${effect.icon}</span><strong>${esc(effect.title)}</strong><span>${esc(effect.text)}</span>${effect.tone==='gold'?`<div class="confetti" aria-hidden="true">${Array.from({length:18},(_,i)=>`<i style="--i:${i};--color:${color(i%8)}"></i>`).join('')}</div>`:''}</div>`;
  }
  function stage(b,s=null) {
    const shown=motion&&s?motion.before:s,p=shown?E.current(shown):null;
    return `<section class="board-stage deluxe-board theme-${b.id}" aria-label="Square game board"><div class="board-meta"><span><span class="small-star">✦</span> ${s?'THE NEIGHBORHOOD IS ALIVE':'CHOOSE YOUR LITTLE WORLD'}</span><span>${b.size} SPACES · ${b.districts.length} DISTRICTS</span></div><div class="camera-controls" aria-label="Board camera">${[['angled','◈ Tabletop'],['top','▦ Top-down'],['follow','◎ Follow']].map(([id,name])=>button(name,'camera','camera-btn '+(settings.camera===id?'selected':''),`data-camera="${id}" aria-pressed="${settings.camera===id}"`)).join('')}</div><div class="camera-stage" data-camera="${settings.camera}"><div class="board-plane" style="${cameraStyle(b,shown)}"><div class="board-face"><div class="world-window"><div class="scene-art art-${b.id}"></div><div class="world-vignette"></div><div class="ambient-cloud cloud-one"></div><div class="ambient-cloud cloud-two"></div><div class="ambient-sparkle"></div><div class="tiny-birds" aria-hidden="true">⌁ &nbsp; ⌁</div></div>${boardSVG(b,shown)}${tokenLayer(b,shown)}<div class="board-center ${s?'game-center':''}"><span class="scene-badge">${s?`TURN ${shown.turn} · ${esc(p.name)}`:'PARCEL & PORT'}</span><h2>${esc(b.name)}</h2>${s?`<div id="board-dice">${diceHTML(motion?game.dice:s.dice,!!motion)}</div><p id="board-move-status">${motion?'Rolling the dice…':s.phase==='finished'?'A neighborhood well made.':'Every corner holds a possibility.'}</p>`:`<p>Build a little world.<br>Make a few big moves.</p><div class="lobby-dice">${diceHTML([3,5])}</div>`}</div></div></div></div>${effectHTML()}<div class="board-foot"><span>↻ ${s?'TAP A SPACE TO EXPLORE':'ORIGINAL WORLDS. ENDLESS POSSIBILITIES.'}</span><span>PASS & PLAY · UP TO 8</span></div></section>`;
  }
  function lobby() {
    const b=E.BOARDS.find(x=>x.id===setup.boardId);
    return `<div class="shell">${header()}${saved?`<div class="resume-banner"><div><strong>${saved.phase==='finished'?'Your last neighborhood':'Your table is still here'}</strong><small>${esc(E.board(saved).name)} · ${saved.players.length} players · Round ${saved.round}</small></div>${button(saved.phase==='finished'?'View results':'Continue game','resume')}</div>`:''}${loadWarning?`<div class="save-warning">${esc(loadWarning)}</div>`:''}<section class="intro"><div><div class="eyebrow">GOOD COMPANY. FRIENDLY COMPETITION.</div><h1>A world of<br><em>possibilities.</em></h1></div><p>A square board. A table full of friends.<br>Roll, trade, and build your way to the top<br>in three beautifully illustrated worlds.</p></section><div class="lobby-layout"><div>${stage(b)}<div class="board-picker" aria-label="Choose a board">${E.BOARDS.map((x,i)=>`<button class="board-option ${x.id===b.id?'active':''}" data-action="board" data-board="${x.id}" aria-pressed="${x.id===b.id}"><div class="board-option-image scene-art art-${x.id}"><span class="world-badge">${x.size} SPACES</span></div><span class="board-no">WORLD 0${i+1}</span>${x.id===b.id?'<span class="check">✓</span>':''}<strong>${esc(x.name)}</strong><small>${x.tag}</small></button>`).join('')}</div></div><section class="setup-card"><div class="section-header"><h2>Your table.</h2><span class="count">${setup.players.length} / 8 seats</span></div><p class="muted">Pass the device. Play with friends, AI, or both.</p><div class="seat-list">${setup.players.map((p,i)=>`<div class="seat">${pawn({id:i})}<label class="sr-only" for="name-${i}">Player ${i+1} name</label><input id="name-${i}" data-seat="${i}" data-field="name" value="${esc(p.name)}" maxlength="24" autocomplete="off"><label class="sr-only" for="type-${i}">Player ${i+1} type</label><select id="type-${i}" data-seat="${i}" data-field="ai">${['human','relaxed','balanced','bold'].map(t=>`<option value="${t}" ${p.ai===t?'selected':''}>${labelAI(t)}</option>`).join('')}</select><button class="remove-seat" data-action="remove" data-id="${i}" aria-label="Remove player ${i+1}" ${setup.players.length<=2?'disabled':''}>×</button></div>`).join('')}</div>${button('+ Add a player','add','add-seat',setup.players.length>=8?'disabled':'')}<div class="divider"></div><div class="field"><label for="length">MAKE AN EVENING OF IT</label><select id="length"><option value="12" ${setup.roundLimit===12?'selected':''}>A quick visit · 12 rounds</option><option value="18" ${setup.roundLimit===18?'selected':''}>The neighborhood game · 18 rounds</option><option value="24" ${setup.roundLimit===24?'selected':''}>An extended stay · 24 rounds</option><option value="36" ${setup.roundLimit===36?'selected':''}>A long evening · 36 rounds</option><option value="0" ${setup.roundLimit===0?'selected':''}>Until one player remains</option></select><p class="muted">Each round gives every active player one turn.</p></div>${button('Let’s play <span>↗</span>','start','primary wide start')}<div class="fine-print">${setup.players.filter(p=>p.ai==='human').length} local · ${setup.players.filter(p=>p.ai!=='human').length} AI · ${credits(b.cash)} starting credits</div><div class="rule-chips"><span>Automatic saves</span><span>No accounts</span><span>100% offline</span></div></section></div><footer class="footer"><span>One device. Everyone at the table.</span><span>ORIGINAL BOARDS · ORIGINAL POSSIBILITIES</span></footer></div>`;
  }
  function eventHTML(){return game.lastEvent?`<div class="event-card">${V.special('event')}<span class="eyebrow">✦ DISPATCH</span><strong>${esc(game.lastEvent.title)}</strong><p>${esc(game.lastEvent.text)}</p></div>`:'';}
  function propertyPicture(t,b,large=false){return `<div class="property-picture ${large?'picture-large':''}"><div class="scene-art art-${b.id}"></div>${t.type==='property'?V.building(b.id,t.id,t.color,game?.deeds[t.id]?.level||0):V.special(t.type)}<span class="picture-caption">${t.type==='property'?esc(b.districts[t.group]).toUpperCase():esc(t.name).toUpperCase()}</span></div>`;}
  function actionsHTML() {
    if(motion){const p=motion.before.players[motion.before.current];return `<section class="panel action-panel motion-panel" aria-label="Movement animation"><div class="eyebrow">${esc(p.name)} · ON THE MOVE</div><div class="motion-avatar">${V.token(p.id,color(p.id))}</div><h2>A little adventure.</h2><p class="phase-desc" id="motion-status" role="status" aria-live="polite">Rolling the dice…</p><div class="journey-progress"><i></i></div>${button('Skip animation →','skip-motion','secondary wide')}<p class="motion-note">Your move is saved. Enjoy the journey.</p></section>`;}
    const s=game,p=E.decisionPlayer(s),ai=p.ai!=='human',t=E.board(s).tiles[E.current(s).position];let title='',description='',actions='';
    switch(s.phase){
      case 'roll':title=p.skipTurns?'Take a breather.':'Your next move.';description=p.skipTurns?'Wait for one turn, or pay 60 credits to clear the delay and roll.':'Roll two dice, follow the loop, and see what the neighborhood has in store.';actions=(p.skipTurns?button('Clear delay · 60','leave','secondary wide',p.cash<60?'disabled':''):'')+button(p.skipTurns?'Wait this turn':'Roll the dice ↗','roll','primary wide');break;
      case 'offer':title=t.name;description=`Make this property yours for ${credits(t.price)} credits. Base rent: ${credits(t.baseRent)}. Complete the district to double it.`;actions=button(`Buy · ${credits(t.price)}`,'buy','primary wide',p.cash<t.price?'disabled':'')+button('Send to auction','auction','secondary wide');break;
      case 'auction':title='Going, going…';description=`${E.property(s,s.auction.tileId).name} · ${s.auction.leader===null?'Opening bid: 10 credits':`Top bid: ${credits(s.auction.bid)} by ${s.players[s.auction.leader].name}`}. ${p.name} bids next. Passing leaves this auction.`;actions=`<form id="bid-form" class="bid-form"><label class="sr-only" for="bid-amount">Your bid</label><input id="bid-amount" type="number" inputmode="numeric" min="${s.auction.bid+10}" max="${p.cash}" value="${s.auction.bid+10}" step="1" required><button class="primary" type="submit">Bid</button></form>`+button('Pass on this property','pass','secondary wide');break;
      case 'debt':title='A little short.';description=`You owe ${credits(s.debt.amount)} credits for ${s.debt.reason}. Sell upgrades or mortgage properties from your portfolio to raise cash.`;actions=button(`Pay ${credits(s.debt.amount)}`,'settle','primary wide',p.cash<s.debt.amount?'disabled':'')+button('Manage my properties','portfolio','secondary wide',`data-id="${p.id}"`)+button('Concede this match','concede-prompt','danger wide');break;
      case 'end':title=p.bankrupt?'Until next time.':'Nicely played.';description=p.bankrupt?'Your remaining assets have been settled. The neighborhood carries on.':s.message;actions=button('End turn · pass the device →','end','primary wide');break;
      case 'trade':title='An offer for you.';description=`${s.players[s.trade.proposer].name} proposes a trade with ${p.name}. Both players must agree before anything changes hands.`;actions=button('Review the trade','review-trade','primary wide');break;
      case 'finished':title='A neighborhood well made.';description='The final standings include cash, properties, and upgrades, less mortgage balances.';actions=button('Final standings','standings','primary wide')+button('Set up another game','lobby','secondary wide');break;
    }
    return `<section class="panel action-panel" aria-label="Turn controls">${['offer','auction'].includes(s.phase)?propertyPicture(s.phase==='auction'?E.property(s,s.auction.tileId):t,E.board(s)):''}<div class="eyebrow">${s.phase==='auction'?'AT THE AUCTION':s.phase==='trade'?'TRADE REVIEW':s.phase==='finished'?'THAT’S A WRAP':`PLAYER ${p.id+1} · ${esc(labelAI(p.ai))}`}</div><h2>${esc(title)}</h2><p class="phase-desc" role="status" aria-live="polite">${esc(description)}</p>${s.phase!=='finished'?`<div class="cash-line"><span>${esc(p.name)}’s cash</span><b class="money">${credits(p.cash)} <small style="font:10px -apple-system,sans-serif">CR</small></b></div>`:''}${eventHTML()}<div class="action-stack">${ai&&s.phase!=='finished'?`<div class="bot-status"><span>●</span> ${esc(p.name)} is thinking…</div>`:actions}</div>${!ai&&['roll','end','offer'].includes(s.phase)&&!p.bankrupt?`<div class="tiny-actions">${button('My properties','portfolio','text-btn',`data-id="${p.id}"`)}${['roll','end'].includes(s.phase)?button('Make a trade','trade','text-btn'):''}</div>`:''}</section>`;
  }
  function gameHTML() {
    const s=motion?motion.before:game,b=E.board(s),decision=E.decisionPlayer(s);
    const winners=s.winners.map(id=>s.players[id].name).join(' & ');
    return `<div class="shell">${header(true)}<div class="game-top"><h2>${esc(b.name)}</h2><span class="round-chip">ROUND ${s.round}${s.roundLimit?' / '+s.roundLimit:' · OPEN ENDED'}</span></div>${s.phase==='finished'?`<div class="result-banner"><div class="eyebrow">✦ THE NEIGHBORHOOD IS YOURS ✦</div><h2>${esc(winners)} ${s.winners.length===1?'wins.':'share the win.'}</h2><p>${s.winners.length?credits(E.wealth(s,s.winners[0])):'0'} credits in total wealth.</p>${button('See final standings','standings','primary')}</div>`:''}<div class="player-strip" aria-label="Players">${s.players.map(p=>`<button class="player-pill ${decision.id===p.id?'current':''} ${p.bankrupt?'out':''}" data-action="portfolio" data-id="${p.id}" aria-label="${esc(p.name)}, ${p.bankrupt?'eliminated':credits(p.cash)+' credits'}, view properties">${pawn(p)}${effect?.changed?.[p.id]?`<span class="cash-delta ${effect.changed[p.id]>0?'positive':'negative'}">${effect.changed[p.id]>0?'+':''}${credits(effect.changed[p.id])}</span>`:''}<span><strong>${esc(p.name)}</strong><small>${p.bankrupt?'OUT OF PLAY':`${credits(p.cash)} CR · ${E.owned(s,p.id).length} lots`}</small></span></button>`).join('')}</div><div class="game-layout"><div>${stage(b,s)}<div class="subnav">${button('All properties','all-properties','text-btn')}${button('Standings','standings','text-btn')}${button('Activity','activity','text-btn')}</div></div><aside class="game-aside">${actionsHTML()}<section class="panel log-panel"><div class="section-header"><span class="eyebrow">AROUND THE TABLE</span><span style="color:#93a48b">↗</span></div><div class="ledger">${s.log.slice(0,4).map(x=>`<div class="ledger-item">${esc(x.text)}</div>`).join('')}</div></section></aside></div>${saveWarning?`<div class="save-warning" role="alert">${esc(saveWarning)}</div>`:''}<footer class="footer"><span>● ${saveWarning?'Autosave unavailable':'Saved on this device'} · ${s.players.length} seats</span><span>PROPERTY, POSSIBILITY &amp; GOOD COMPANY.</span></footer></div>`;
  }
  function persistSettings(){try{localStorage.setItem(SETTINGS_KEY,JSON.stringify(settings));}catch{}}
  function motionEnabled(){return settings.animations&&!window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;}
  function sound(kind){
    if(!settings.sound)return;
    try{
      const Audio=window.AudioContext||window.webkitAudioContext;if(!Audio)return;
      if(!audioContext)audioContext=new Audio();if(audioContext.state==='suspended')audioContext.resume().catch(()=>{});
      const notes=kind==='hop'?[310]:kind==='roll'?[140,190,150,230]:kind==='purchase'?[523,659,784]:kind==='upgrade'?[392,523,784,1047]:kind==='win'?[523,659,784,1047,1319]:[440,550];
      notes.forEach((frequency,i)=>{const osc=audioContext.createOscillator(),gain=audioContext.createGain(),at=audioContext.currentTime+i*.085;osc.type=kind==='hop'?'sine':'triangle';osc.frequency.setValueAtTime(frequency,at);gain.gain.setValueAtTime(0,at);gain.gain.linearRampToValueAtTime(kind==='hop'?.035:.055,at+.012);gain.gain.exponentialRampToValueAtTime(.001,at+.13);osc.connect(gain);gain.connect(audioContext.destination);osc.start(at);osc.stop(at+.15);});
    }catch{}
  }
  function haptic(kind){try{window.webkit?.messageHandlers?.parcelHaptic?.postMessage(kind);}catch{}}
  function flash(before,after,action){
    const p=before.players[before.current],changed=after.players.map((x,i)=>x.cash-before.players[i].cash);
    const t=E.board(after).tiles[action.id===undefined?p.position:action.id];
    let title='',text='',icon='✦',tone='mint';
    if(after.phase==='finished'){title=after.winners.map(id=>after.players[id].name).join(' & ')+' wins!';text='Your neighborhood. Your moment.';icon='★';tone='gold';sound('win');}
    else if(action.type==='buy'){title='A new address!';text=t.name+' belongs to '+p.name;icon='⌂';tone='gold';sound('purchase');}
    else if(action.type==='build'){title='On the rise!';text=t.name+' · upgrade tier '+after.deeds[t.id].level;icon='↑';tone='gold';sound('upgrade');}
    else if(action.type==='accept'){title='Deal made.';text='A new chapter for both neighborhoods.';icon='⇄';sound('purchase');}
    else if(before.phase==='auction'&&after.phase==='end'&&after.deeds[before.auction.tileId].owner!==null){title='Sold!';text=E.property(after,before.auction.tileId).name+' has a new owner.';icon='◆';tone='gold';sound('purchase');}
    else if(action.type==='roll'&&after.lastEvent){title=after.lastEvent.title;text=after.lastEvent.text;icon='✉';sound('event');}
    else if(changed[p.id]){title=changed[p.id]>0?'Credits received':'Payment complete';text=`${changed[p.id]>0?'+':''}${credits(changed[p.id])} credits · ${p.name}`;icon=changed[p.id]>0?'+':'−';tone=changed[p.id]>0?'mint':'coral';}
    if(!title)return;
    effect={title,text,icon,tone,changed};clearTimeout(effectTimer);
    effectTimer=setTimeout(()=>{effect=null;document.querySelector?.('.action-effect')?.remove();document.querySelectorAll?.('.cash-delta').forEach(el=>el.remove());},2400);
    haptic(tone==='gold'?'success':'light');
  }
  function finishMovement(repaint=true){
    if(!motion)return;const before=motion.before;
    for(const timer of movementTimers)clearTimeout(timer);movementTimers=[];motion=null;
    flash(before,game,{type:'roll'});if(repaint)render();
  }
  function later(fn,delay){const id=setTimeout(()=>{movementTimers=movementTimers.filter(x=>x!==id);fn();},delay);movementTimers.push(id);}
  function beginMovement(before){
    clearTimeout(botTimer);effect=null;motion={before,trail:V.movement(before,game),index:0};
    render();sound('roll');haptic('light');
    later(()=>{
      if(!motion)return;
      const dice=document.getElementById('board-dice');if(dice)dice.innerHTML=diceHTML(game.dice);
      const status=document.getElementById('motion-status');if(status)status.textContent=`${game.dice.join(' + ')} = ${game.lastRoll}. Here we go!`;
      later(advanceMovement,settings.tempo==='quick'?80:220);
    },settings.tempo==='quick'?350:850);
  }
  function advanceMovement(){
    if(!motion)return;
    if(motion.index>=motion.trail.length){later(()=>finishMovement(),settings.tempo==='quick'?80:240);return;}
    const step=motion.trail[motion.index++],id=motion.before.current,b=E.board(game),point=V.tokenPoint(b.size,step.position);
    const token=document.getElementById('board-token-'+id);
    if(token&&token.style){token.style.left=point.x/6.4+'%';token.style.top=point.y/6.4+'%';token.classList.remove('token-hopping');void token.offsetWidth;token.classList.add('token-hopping');}
    const plane=document.querySelector?.('.board-plane');if(plane){plane.style.setProperty('--focus-x',(320-point.x)/640*100+'%');plane.style.setProperty('--focus-y',(320-point.y)/640*100+'%');}
    const title=step.teleport?'Taking a shortcut…':b.tiles[step.position].name;
    const label=document.getElementById('board-move-status');if(label)label.textContent=title;
    const status=document.getElementById('motion-status');if(status)status.textContent=title;
    const bar=document.querySelector?.('.journey-progress i');if(bar)bar.style.width=(motion.index/motion.trail.length*100)+'%';
    sound('hop');
    later(advanceMovement,settings.tempo==='quick'?75:step.teleport?400:175);
  }
  function render(){clearTimeout(botTimer);root.innerHTML=game?gameHTML():lobby();if(modalState)renderModal();scheduleAI();}
  function scheduleAI(){clearTimeout(botTimer);if(!game||motion||modalState||document.hidden||game.phase==='finished')return;const a=E.botAction(game);if(a)botTimer=setTimeout(()=>perform(a,true),fastAI?180:900);}
  function perform(action,bot=false) {
    if(!game)return;
    if(motion){toast('Let the piece finish moving, or skip the animation.');return;}
    const before=game;
    const previous=E.decisionPlayer(game).id,turn=game.turn;
    if(!bot&&E.decisionPlayer(game).ai!=='human'&&!['build','sell','mortgage','redeem'].includes(action.type)){toast('This player is controlled by AI.');return;}
    try{
      game=E.act(game,action);save();
      if(action.type==='roll'&&!before.players[before.current].skipTurns&&motionEnabled()){beginMovement(before);return;}
      flash(before,game,action);
      const next=E.decisionPlayer(game);
      if(game.phase!=='finished'&&next.ai==='human'&&(previous!==next.id||turn!==game.turn)){
        modalState={kind:'handoff',id:next.id};
      }else if(modalState&&['review-trade','concede-prompt'].includes(modalState.kind)){modalState=null;dialog.close();}
      render();
      if(modalState&&!dialog.open)dialog.showModal();
    }catch(e){toast(e.message);if(bot)showModal('ai-error',{message:e.message});}
  }
  function startGame(){finishMovement(false);effect=null;game=E.createGame(setup);save();modalState=null;dialog.close();render();if(E.current(game).ai==='human')showModal('handoff',{id:game.current});}
  function showModal(kind,data={}){finishMovement(false);clearTimeout(botTimer);modalState={kind,...data};renderModal();if(!dialog.open)dialog.showModal();}
  function closeModal(){modalState=null;dialog.close();render();}
  function propertyRow(t,s=game){const d=s.deeds[t.id];return `<button class="portfolio-row" style="--accent:${t.color}" data-action="tile" data-id="${t.id}"><span class="lot-thumb">${V.building(E.board(s).id,t.id,t.color,d.level)}</span><span class="lot-copy"><strong>${esc(t.name)}</strong><small>${d.owner===null?'Available':esc(s.players[d.owner].name)} · ${d.mortgaged?'Mortgaged':`Tier ${d.level}`}</small></span><span class="money">${credits(E.rent(s,t.id))}<small>RENT / CR</small></span></button>`;}
  function tradeReview(){const t=game.trade;return `<p>Pass the device to <strong>${esc(game.players[t.target].name)}</strong>. Review both sides before accepting.</p><div class="trade-summary"><div><strong>${esc(game.players[t.target].name)} receives</strong><br>${credits(t.giveCash)} credits${t.giveIds.map(id=>'<br>+ '+esc(E.property(game,id).name)+(game.deeds[id].mortgaged?' (mortgaged)':'')).join('')}</div><div><strong>${esc(game.players[t.target].name)} gives</strong><br>${credits(t.takeCash)} credits${t.takeIds.map(id=>'<br>− '+esc(E.property(game,id).name)+(game.deeds[id].mortgaged?' (mortgaged)':'')).join('')}</div></div><p>Mortgages stay attached to traded properties. There is no transfer fee.</p><div class="action-pair">${button('Decline','reject','secondary')}${button('Accept trade','accept')}</div>`;}
  function renderModal(){
    if(!modalState)return;const m=modalState;let title='',body='';
    if(m.kind==='help'){
      title='A neighborhood of your own.';
      body=`<p>Parcel &amp; Port is an original, offline property trading game for 2–8 players. Share one device, add AI seats, or watch an all-AI match.</p><ol><li><strong>Roll and explore.</strong> Roll two dice and move clockwise. Collect the board’s salary whenever you pass Home Port. Doubles do not grant an extra turn.</li><li><strong>Buy or bid.</strong> Buy an available property at its price, or send it to auction. All active players, including the player who declined, may bid. Each bid must be at least 10 credits higher. Passing removes you from that auction.</li><li><strong>Build a district.</strong> Collect all three matching properties to double base rent. With no mortgages in the district, build evenly through three tiers. Tier rent is 4×, 9×, then 16× base rent.</li><li><strong>Trade and grow.</strong> Before rolling or after resolving a turn, offer cash and properties to another player. They must accept. Sell all upgrades in a district before trading any of its properties.</li><li><strong>Keep cash handy.</strong> Other players’ properties charge rent. City Levies and Dispatches can also cost you credits. If cash runs out, sell upgrades for half cost or mortgage unimproved properties for half their price.</li><li><strong>Keep your neighborhood working.</strong> Mortgaged properties collect no rent. Redeem them for the borrowed amount plus 10%, rounded up. A district with a mortgage loses its base-rent bonus.</li><li><strong>Take a breather.</strong> Landing normally on Breather gives 40 credits. A Detour sends you there without a bonus; next turn, wait instead of rolling or pay 60 to leave.</li><li><strong>Finish on top.</strong> A timed game ends after every active player has had their turn in the final round. Highest wealth wins: cash + purchase prices + full upgrade costs − mortgage principal. Ties share the win. An open-ended match ends when one player remains.</li></ol><h3>If you cannot pay</h3><p>Manage your portfolio until you can settle the full amount. Selling upgrades must remain even across the district. If you concede, your remaining cash and assets go to the creditor; debts to the city return properties to the market. Eliminated players cannot win a timed game.</p><h3>Three AI personalities</h3><p><strong>Relaxed</strong> keeps a bigger cash cushion. <strong>Balanced</strong> weighs price and district potential. <strong>Bold</strong> bids more aggressively and values completing or blocking districts. AI uses the same dice, prices, and rules as everyone else.</p><h3>Your view of the table</h3><p>Use Tabletop for an angled board, Top-down to read the whole square, or Follow to pan toward the active piece. Dice tumble, pieces hop space by space, and purchases and upgrades have their own effects. Skip any move animation, or adjust movement speed, sound, and animations in the pause menu. System Reduce Motion is respected.</p><h3>Made for the same room</h3><p>Local means pass-and-play on one iPhone or iPad. There are no accounts, servers, ads, trackers, or online multiplayer. Every decision saves automatically on this device. Closing the app pauses AI turns.</p>`;
    } else if(m.kind==='handoff'){
      const p=game.players[m.id];title='Pass the device.';body=`<div class="handoff-illustration scene-art art-${game.boardId}"></div><div class="handoff">${pawn(p)}<div class="eyebrow">PLAYER ${p.id+1} · YOUR SEAT IS READY</div><h2>${esc(p.name)}.</h2><p>${game.phase==='auction'?'It’s your turn to bid.':game.phase==='trade'?'There’s a trade for you to review.':'The neighborhood is waiting for your next move.'}</p>${button('I’m ready →','close','primary wide')}</div>`;
    } else if(m.kind==='overwrite'){
      title='A fresh neighborhood?';body=`<p>Starting this match replaces the saved game on this device. Your current setup has ${setup.players.length} players on ${esc(E.BOARDS.find(x=>x.id===setup.boardId).name)}.</p><div class="action-pair">${button('Keep saved game','close','secondary')}${button('Start new game','start-confirm')}</div>`;
    } else if(m.kind==='menu'){
      title='Take your time.';body=`<p>Your game is saved. AI turns are paused while this menu is open.</p><div class="field"><label for="ai-speed">AI TURN SPEED</label><select id="ai-speed"><option value="normal" ${fastAI?'':'selected'}>Unhurried · follow every move</option><option value="fast" ${fastAI?'selected':''}>Quick · keep things moving</option></select></div><div class="setting-row"><div class="field"><label for="animation-setting">ANIMATIONS</label><select id="animation-setting"><option value="on" ${settings.animations?'selected':''}>On</option><option value="off" ${settings.animations?'':'selected'}>Off</option></select></div><div class="field"><label for="motion-speed">MOVEMENT</label><select id="motion-speed"><option value="normal" ${settings.tempo==='normal'?'selected':''}>Cinematic</option><option value="quick" ${settings.tempo==='quick'?'selected':''}>Quick</option></select></div><div class="field"><label for="sound-setting">SOUND</label><select id="sound-setting"><option value="off" ${settings.sound?'':'selected'}>Off</option><option value="on" ${settings.sound?'selected':''}>On</option></select></div></div><div class="action-stack">${button('Back to the table','close','primary wide')}${button('How to play','help','secondary wide')}${button('Return to setup','lobby','secondary wide')}</div><p style="margin-top:17px">Returning to setup keeps your saved match. Start a new match only when you’re ready to replace it.</p>`;
    } else if(m.kind==='tile'){
      const b=game?E.board(game):E.BOARDS.find(x=>x.id===setup.boardId),t=b.tiles[m.id];title=t.name;
      if(t.type!=='property'){
        const descriptions={start:`Collect ${b.salary} credits whenever you pass Home Port.`,event:'Draw an original Dispatch card. Some offer grants; others charge upkeep, change your route, or cause a planning delay.',fee:`Pay ${b.fee} credits to the city.`,rest:'Collect 40 credits when you land here normally. If sent here by a Detour or a planning delay, skip your next roll or pay 60 to leave.',detour:'Move to Breather without collecting a reward. On your next turn, wait instead of rolling or pay 60 to leave.',dividend:'Collect a 100-credit local grant.'};body=propertyPicture(t,b,true)+`<p>${descriptions[t.type]}</p>`;
      }else{
        const d=game?.deeds[t.id];
        body=propertyPicture(t,b,true)+`<div class="property-banner" style="--accent:${t.color}"><small>${esc(b.districts[t.group]).toUpperCase()}</small><h3>${esc(t.name)}</h3><span class="muted">${game?(d.owner===null?'Available to buy':`Owned by ${esc(game.players[d.owner].name)} · ${d.mortgaged?'Mortgaged':`Tier ${d.level}`}`):'Three properties make a district.'}</span></div><div class="property-stats"><div><small>PRICE</small><strong>${credits(t.price)}</strong></div><div><small>${game?'CURRENT':'BASE'} RENT</small><strong>${credits(game?E.rent(game,t.id):t.baseRent)}</strong></div><div><small>UPGRADE COST</small><strong>${credits(t.buildCost)}</strong></div></div><p>District rent ${t.baseRent*2} · Tier 1 ${t.baseRent*4} · Tier 2 ${t.baseRent*9} · Tier 3 ${t.baseRent*16} credits.</p>`;
        if(game&&d.owner===game.current&&E.current(game).ai==='human'&&game.phase!=='finished'){
          body+=`<div class="detail-list">${[['build','Add an upgrade',`Pay ${t.buildCost}`],['sell','Sell one upgrade',`Receive ${Math.floor(t.buildCost/2)}`],[d.mortgaged?'redeem':'mortgage',d.mortgaged?'Redeem mortgage':'Mortgage property',d.mortgaged?`Pay ${E.redemption(t)}`:`Receive ${Math.floor(t.price/2)}`]].map(([type,name,cost])=>{const error=E.manageError(game,type,t.id);return `<div class="detail-row"><div><strong>${name}</strong><p>${esc(error||cost+' credits')}</p></div>${button(cost,type,'secondary',`data-id="${t.id}" ${error?'disabled':''}`)}</div>`;}).join('')}</div>`;
        }
        if(game){body+=`<h3>The ${esc(b.districts[t.group])} district</h3><div class="portfolio">${E.groupTiles(game,t.group).map(x=>propertyRow(x)).join('')}</div>`;}
      }
    } else if(m.kind==='portfolio'||m.kind==='all-properties'){
      const all=m.kind==='all-properties',p=all?null:game.players[m.id],list=all?E.board(game).tiles.filter(t=>t.type==='property'):E.owned(game,p.id);
      title=all?'The property ledger.':`${p.name}’s portfolio.`;
      body=`<p>${all?'Every corner of the neighborhood. Tap a property to see its district, rent, and owner.':`${credits(p.cash)} cash · ${credits(E.wealth(game,p.id))} total wealth. Tap an owned property to manage it during your turn.`}</p><div class="portfolio">${list.length?list.map(t=>propertyRow(t)).join(''):'<div class="empty">A fresh start. No properties yet.</div>'}</div>`;
    } else if(m.kind==='standings'){
      title='Around the table.';const standings=[...game.players].sort((a,b)=>Number(a.bankrupt)-Number(b.bankrupt)||E.wealth(game,b.id)-E.wealth(game,a.id));body=`<p>Wealth counts cash, purchase prices, and full upgrade costs, less mortgage principal.</p><div class="standings">${standings.map((p,i)=>`<div class="standing"><span>${i+1}</span>${pawn(p)}${effect?.changed?.[p.id]?`<span class="cash-delta ${effect.changed[p.id]>0?'positive':'negative'}">${effect.changed[p.id]>0?'+':''}${credits(effect.changed[p.id])}</span>`:''}<span><strong>${esc(p.name)}</strong><small>${p.bankrupt?'Eliminated':`${E.owned(game,p.id).length} properties · ${labelAI(p.ai)}`}</small></span><strong class="money">${credits(E.wealth(game,p.id))}</strong></div>`).join('')}</div>`;
    } else if(m.kind==='activity'){
      title='The neighborhood journal.';body=`<div class="ledger">${game.log.map(x=>`<div class="ledger-item"><span><strong>Turn ${x.turn}</strong><br>${esc(x.text)}</span></div>`).join('')}</div>`;
    } else if(m.kind==='trade'){
      const p=E.current(game),others=E.active(game).filter(x=>x.id!==p.id),target=others.find(x=>x.id===m.target)||others[0];m.target=target.id;title='Make a little deal.';
      const picks=(who,kind)=>E.owned(game,who).filter(t=>E.tradeable(game,t.id,who)).map(t=>`<label class="trade-check"><input type="checkbox" name="${kind}" value="${t.id}"><span class="trade-lot-art">${V.building(game.boardId,t.id,t.color,0)}</span><span>${esc(t.name)}${game.deeds[t.id].mortgaged?' · mortgaged':''}</span></label>`).join('')||'<p>No tradable properties.</p>';
      body=`<p>Swap properties, credits, or both. The other player gets the final say. Properties in districts with upgrades cannot be traded.</p><form id="trade-form"><div class="field"><label for="trade-target">WHO’S AT THE OTHER SIDE?</label><select id="trade-target">${others.map(x=>`<option value="${x.id}" ${x.id===target.id?'selected':''}>${esc(x.name)} · ${labelAI(x.ai)}</option>`).join('')}</select></div><div class="trade-grid"><div class="trade-side"><h3>You give</h3><label for="give-cash" class="muted">Credits · max ${credits(p.cash)}</label><input id="give-cash" name="giveCash" type="number" inputmode="numeric" min="0" max="${p.cash}" step="1" value="0" required>${picks(p.id,'giveIds')}</div><div class="trade-side"><h3>You receive</h3><label for="take-cash" class="muted">Credits · max ${credits(target.cash)}</label><input id="take-cash" name="takeCash" type="number" inputmode="numeric" min="0" max="${target.cash}" step="1" value="0" required>${picks(target.id,'takeIds')}</div></div><button class="primary wide" style="margin-top:18px" type="submit">Propose trade →</button></form>`;
    } else if(m.kind==='review-trade'){
      title='A fair exchange?';body=tradeReview();
    } else if(m.kind==='concede-prompt'){
      title='Leave this neighborhood?';body=`<p>${esc(E.current(game).name)} will be eliminated. Remaining cash and properties go ${game.debt.creditor===null?'back to the city':`to ${esc(game.players[game.debt.creditor].name)}`}. You can still return to your portfolio and try to raise the payment.</p><div class="action-pair">${button('Keep playing','close','secondary')}${button('Concede match','concede','danger')}</div>`;
    } else if(m.kind==='ai-error'){title='The table is paused.';body=`<p>${esc(m.message)}</p><p>The last valid state is still saved. Return to setup to resume it.</p>${button('Return to setup','lobby','primary wide')}`;}
    dialog.innerHTML=`<header class="modal-head"><h2 id="modal-title">${esc(title)}</h2>${button('×','close','icon-btn','aria-label="Close dialog"')}</header><div class="modal-body">${body}</div>`;
  }
  function handleClick(event){
    const el=event.target.closest('[data-action]');if(!el||el.disabled)return;const a=el.dataset.action,id=Number(el.dataset.id);
    if(a==='home')return;
    if(a==='skip-motion'){finishMovement();return;}
    if(a==='camera'){if(['angled','top','follow'].includes(el.dataset.camera)){finishMovement(false);settings.camera=el.dataset.camera;persistSettings();render();}return;}
    if(a==='sound'){settings.sound=!settings.sound;persistSettings();if(settings.sound)sound('purchase');render();return;}
    if(a==='board'){setup.boardId=el.dataset.board;render();return;}
    if(a==='add'){if(setup.players.length<8)setup.players.push({name:names[setup.players.length],ai:'human'});render();return;}
    if(a==='remove'){if(setup.players.length>2)setup.players.splice(id,1);render();return;}
    if(a==='start'){saved?showModal('overwrite'):startGame();return;}
    if(a==='start-confirm'){startGame();return;}
    if(a==='resume'){game=E.restore(E.serialize(saved));render();if(game.phase!=='finished'&&E.decisionPlayer(game).ai==='human')showModal('handoff',{id:E.decisionPlayer(game).id});return;}
    if(a==='close'){closeModal();return;}
    if(a==='lobby'){finishMovement(false);effect=null;save();game=null;modalState=null;dialog.close();render();return;}
    if(['help','menu','tile','portfolio','standings','activity','all-properties','trade','review-trade','concede-prompt'].includes(a)){showModal(a,{id});return;}
    if(['roll','leave','buy','auction','pass','end','settle','concede','accept','reject','build','sell','mortgage','redeem'].includes(a)){perform({type:a,id});return;}
  }
  document.addEventListener('click',handleClick);
  document.addEventListener('keydown',e=>{const tile=e.target.closest('.tile');if(tile&&['Enter',' '].includes(e.key)){e.preventDefault();showModal('tile',{id:Number(tile.dataset.id)});}});
  document.addEventListener('input',e=>{const el=e.target;if(el.dataset.seat!==undefined)setup.players[Number(el.dataset.seat)][el.dataset.field]=el.value;});
  document.addEventListener('change',e=>{const el=e.target;if(el.id==='length'){setup.roundLimit=Number(el.value);}if(el.dataset.field==='ai'){setup.players[Number(el.dataset.seat)].ai=el.value;render();}if(el.id==='ai-speed')fastAI=el.value==='fast';if(el.id==='animation-setting'){settings.animations=el.value==='on';persistSettings();}if(el.id==='motion-speed'){settings.tempo=el.value==='quick'?'quick':'normal';persistSettings();}if(el.id==='sound-setting'){settings.sound=el.value==='on';persistSettings();if(settings.sound)sound('purchase');}if(el.id==='trade-target')showModal('trade',{target:Number(el.value)});});
  document.addEventListener('submit',e=>{
    e.preventDefault();if(e.target.id==='bid-form'){perform({type:'bid',amount:Number(document.getElementById('bid-amount').value)});}
    if(e.target.id==='trade-form'){
      const data=new FormData(e.target),action={type:'propose',target:Number(document.getElementById('trade-target').value),giveCash:Number(data.get('giveCash')),takeCash:Number(data.get('takeCash')),giveIds:data.getAll('giveIds').map(Number),takeIds:data.getAll('takeIds').map(Number)};
      try{const result=E.act(game,action);modalState=null;dialog.close();game=result;save();render();if(E.decisionPlayer(game).ai==='human')showModal('review-trade');}catch(error){toast(error.message);}
    }
  });
  dialog.addEventListener('cancel',e=>{e.preventDefault();closeModal();});
  document.addEventListener('visibilitychange',()=>{if(document.hidden){clearTimeout(botTimer);finishMovement();save();}else scheduleAI();});
  window.addEventListener('pagehide',()=>{finishMovement(false);save();});
  window.addEventListener('parcel-save-error',()=>{saveWarning='The device could not write its backup save. Keep the app open until storage is available.';if(game)render();});
  render();
})();
