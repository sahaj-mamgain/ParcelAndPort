# Validation record — illustrated square-board update

## Passed

- **31 rules tests:** seat limits, all three boards, deterministic rolls, purchases, landing rent, every Dispatch card, salaries, levies, detours, auctions, evenly built/sold upgrades, mortgage arithmetic, debt, elimination, trades, AI valuation, round endings, ties, and save validation.
- **15 application-logic tests:** eight-seat setup, board selection, escaping player names, handoff state, replacement-save confirmation, auction and trade decisions, mortgage controls, pausing AI, unavailable storage, native-bridge save messages, committing a roll once before animation, skipping safely, backgrounding during a move, Reduce Motion, and camera preference persistence. These run the app code with a lightweight DOM/event harness; they are not real-browser layout tests.
- **6 presentation tests:** all three perimeter layouts are square and nonoverlapping, all spaces can hold eight distinct piece anchors, animated routes match dice and event outcomes, waiting turns have no fake movement, eight player illustrations are defined, and dice have six faces with the settled orientation.
- **225 baseline deterministic full-match simulations (unchanged rules engine):** 25 seeds × 3 boards × 3 player counts (2, 4, 8), with 24-round limits and mixed AI personalities. Every match finished. There were **66,493 actions, 245 proposed trades, and 23 eliminations**. Save/restore round-trips were exercised during simulations, and state invariants were checked after every action.
- JavaScript syntax checks.
- Swift source syntax parsing with the available Swift compiler. This does not type-check UIKit/SwiftUI against an iOS SDK.
- Xcode project and Info/Privacy plist syntax validation.
- Shell script syntax checks; missing-SDK preflight reports the real blocker and creates no IPA.
- Local-only resource inspection: no remote scripts/fonts, game network calls, or third-party board-game branding in bundled runtime files.
- Standalone HTML preview generated from the exact bundled CSS and JavaScript, with the generated scene atlas embedded once as a data URI. No network asset requests are required.

## Not yet verified

- **Native compilation, iOS simulator execution, device installation, IPA export, and signing:** full Xcode and the iOS SDK were absent on this Mac.
- **Visual rendering and real browser touch/keyboard behavior:** local file navigation was previously blocked, and the preview browser connection was unavailable during the update. The user-provided reference demo was visually inspected before that connection became unavailable. No visual pass of the updated game is claimed.
- **GitHub build workflow:** included for the owner's repository, but not run or published during this task.
- **Native save persistence across force quits, app updates, and memory pressure:** the bridge logic is present; it still needs a real iOS build/device check.
- **Open-ended match termination:** timed matches are covered by the simulations. Open-ended property games can last indefinitely with passive players; use a round limit for predictable sessions.

## Commands

```bash
node --test tests/engine.test.cjs tests/ui-logic.test.cjs tests/visuals.test.cjs
node tests/stress.cjs
python3 scripts/package-preview.py
bash scripts/build-ipa.sh --unsigned
```

## First-device acceptance pass

After building, run on an iPhone and iPad in portrait and landscape. Check Tabletop, Top-down, and Follow views; dice tumbling and every space hop; skipping and backgrounding mid-animation; generated illustration loading in airplane mode; sound after enabling it; native haptics on supported hardware; and system Reduce Motion. Start eight local seats on each board; try a mixed human/AI match; buy and auction a property; complete a trade; manage upgrades and mortgages; trigger a debt and elimination; close/reopen the app during a handoff, auction, and trade; confirm airplane-mode play and restoration. Check large text, screen safe areas, VoiceOver labels, and the 40-stop board's readable property ledger. Verify an IPA signed for the intended device installs and launches.
