#!/usr/bin/env python3
"""Draw the original geometric town icon as opaque RGB PNGs using only stdlib."""
import json, math, struct, zlib
from pathlib import Path
root = Path(__file__).resolve().parents[1] / "ios" / "ParcelAndPort" / "Assets.xcassets"
icons = root / "AppIcon.appiconset"
icons.mkdir(parents=True, exist_ok=True)
def pixel(x, y):
    # Coordinates are on a 1024-point design grid. These are original geometric shapes.
    ink=(23,64,54); gold=(224,189,111); cream=(240,232,201); mint=(144,178,143)
    c=ink
    radius=math.hypot(x-512,y-512)
    if 377 < radius < 381: c=(75,111,86)
    if 185<x<839 and 746<y<755: c=gold
    if 220<x<367 and 435<y<740: c=mint
    if 420<x<590 and 297<y<740: c=cream
    if 640<x<804 and 495<y<740: c=gold
    if 205<x<381 and 400<y<437: c=mint
    if 405<x<605 and 262<y<300: c=cream
    if 624<x<820 and 460<y<498: c=gold
    if 484<x<525 and 212<y<265: c=gold
    for bx,by in [(251,482),(309,482),(251,548),(309,548),(457,345),(524,345),(457,421),(524,421),(457,497),(524,497),(675,543),(738,543),(675,606),(738,606)]:
        if bx<x<bx+25 and by<y<by+32: c=ink
    for bx,by,w in [(270,654,47),(474,615,62),(698,681,47)]:
        if bx<x<bx+w and by<y<745: c=ink
        if math.hypot(x-(bx+w/2),y-by)<w/2: c=ink
    if math.hypot(x-715,y-322)<47: c=gold
    if 272<x<278 and 295<y<337 or 254<x<296 and 313<y<319: c=gold
    return c
def png(path,size):
    raw=bytearray()
    # Four-sample coverage keeps edges clean at the smaller icon sizes.
    for y in range(size):
        raw.append(0)
        for x in range(size):
            samples=[pixel((x+dx)*1024/size,(y+dy)*1024/size) for dx,dy in ((.25,.25),(.75,.25),(.25,.75),(.75,.75))]
            raw.extend(sum(c[i] for c in samples)//4 for i in range(3))
    def chunk(kind,data): return struct.pack('>I',len(data))+kind+data+struct.pack('>I',zlib.crc32(kind+data)&0xffffffff)
    path.write_bytes(b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',size,size,8,2,0,0,0))+chunk(b'IDAT',zlib.compress(raw,9))+chunk(b'IEND',b''))
entries=[]
for idiom,sizes in [('iphone',[(20,[2,3]),(29,[2,3]),(40,[2,3]),(60,[2,3])]),('ipad',[(20,[1,2]),(29,[1,2]),(40,[1,2]),(76,[1,2]),(83.5,[2])]),('ios-marketing',[(1024,[1])])]:
    for points,scales in sizes:
        for scale in scales:
            pixels=int(points*scale);filename=f'Icon-{pixels}.png'
            if not (icons/filename).exists():png(icons/filename,pixels)
            entries.append({'idiom':idiom,'size':f'{points}x{points}','scale':f'{scale}x','filename':filename})
(icons/'Contents.json').write_text(json.dumps({'images':entries,'info':{'version':1,'author':'xcode'}},indent=2))
(root/'Contents.json').write_text(json.dumps({'info':{'version':1,'author':'xcode'}}))
launch=root/'LaunchBackground.colorset';launch.mkdir(exist_ok=True)
(launch/'Contents.json').write_text(json.dumps({'colors':[{'idiom':'universal','color':{'color-space':'srgb','components':{'red':'0.961','green':'0.953','blue':'0.922','alpha':'1.000'}}}],'info':{'version':1,'author':'xcode'}},indent=2))
print(f'Created {len(entries)} app icon entries.')
