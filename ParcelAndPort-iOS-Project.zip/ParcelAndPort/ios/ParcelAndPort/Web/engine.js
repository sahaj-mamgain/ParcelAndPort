/* Parcel & Port — original offline property-trading rules. No dependencies. */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.Parcel = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const VERSION = 1;
  const COLORS = ['#dd8668','#5ab6a3','#7da5d6','#c9a355','#a490c5','#85ad67','#d082a0','#7dbac1','#d19d72','#92a3b4'];
  const PLAYER_COLORS = ['#ef7759','#55c3ab','#e9bd55','#87a9f1','#bd8de0','#ef93b6','#9fca6d','#a6b6bf'];
  const BOARD_SPECS = [
    {id:'harbor', name:'Harbor Hop', subtitle:'A little coast. Big ambitions.', tag:'QUICK & COZY', size:24, cash:1400, salary:200, fee:90, accent:'#5ab6a3',
     districts:['Old Quay','Salt Gardens','Lantern Ward','Tide Market','Coral Heights','Sunset Point'],
     names:['Driftwood Row','Pebble Lane','Anchor Walk','Seagrass Court','Sage Terrace','Marigold Pier','Beacon Street','Copper Lane','Firefly Square','Sailmaker Row','Compass Court','Wharf Arcade','Shell Avenue','Azure Terrace','Pearl Promenade','Golden Steps','Horizon House','Solstice Point']},
    {id:'metro', name:'Midnight Metro', subtitle:'Build your own city after dark.', tag:'THE CITY CLASSIC', size:32, cash:1600, salary:220, fee:120, accent:'#a490c5',
     districts:['Brick Quarter','Foundry Ward','Garden Mile','Neon Market','Canal District','Culture Row','Glass Heights','Crown Terrace'],
     names:['Kiln Lane','Mason Street','Brickworks Yard','Alloy Avenue','Rivet Row','Forge Square','Willow Walk','Fern Court','Orchard Plaza','Violet Alley','Arcade Lane','Prism Market','Lockside Row','Ripple Street','Bridge House','Gallery Walk','Sonnet Square','Atelier Avenue','Atrium Court','Skyglass Row','Helix Tower','Crest Avenue','Regent Steps','Halo Terrace']},
    {id:'alpine', name:'Alpine Trails', subtitle:'Follow the ridge. Own the view.', tag:'ROOM FOR EIGHT', size:40, cash:1800, salary:250, fee:140, accent:'#85ad67',
     districts:['Pine Hollow','Brookside','Stone Village','Wildflower Vale','Lake District','High Meadow','Silver Forest','Cloud Pass','Aurora Ridge','Summit Circle'],
     names:['Cone Lane','Needle Row','Pine Lodge','Brook Bend','Moss Walk','Creek Mill','Slate Street','Granite Court','Cairn Square','Clover Lane','Aster Field','Poppy Terrace','Reed Pier','Mirror Bay','Lake House','Cedar Rise','Heather Hill','Meadow Hall','Birch Walk','Aspen Row','Silver Lodge','Mist Lane','Cloud Bridge','Drift House','Glacier Walk','Aurora Point','Polar Terrace','Eagle Path','Peak House','Summit Observatory']}
  ];
  const SPECIALS = ['start','event','fee','rest','event','detour','dividend','event','fee','event'];
  const SPECIAL_NAMES = {start:'Home Port',event:'Dispatch',fee:'City Levy',rest:'Breather',detour:'Detour',dividend:'Local Grant'};
  const BOARDS = BOARD_SPECS.map(spec => {
    let propertyIndex=0;
    const tiles = Array.from({length:spec.size}, (_,id) => {
      if(id%4===0) {const type=SPECIALS[id/4]; return {id,type,name:SPECIAL_NAMES[type]};}
      const group=Math.floor(propertyIndex/3), name=spec.names[propertyIndex++];
      const price=100+group*30+(id%4-1)*20;
      return {id,type:'property',name,group,color:COLORS[group],price,baseRent:12+group*5+(id%4-1)*3,buildCost:60+group*15};
    });
    return {...spec,tiles};
  });
  const board = s => BOARDS.find(b=>b.id===s.boardId);
  const current = s => s.players[s.current];
  const active = s => s.players.filter(p=>!p.bankrupt);
  const property = (s,id) => board(s).tiles.find(t=>t.id===id&&t.type==='property');
  const groupTiles = (s,group) => board(s).tiles.filter(t=>t.type==='property'&&t.group===group);
  const owned = (s,id) => board(s).tiles.filter(t=>t.type==='property'&&s.deeds[t.id].owner===id);
  const ownsGroup = (s,id,group) => groupTiles(s,group).every(t=>s.deeds[t.id].owner===id);
  function assert(ok,message) {if(!ok) throw new Error(message);}
  function integer(n,min=0,max=1e9) {return Number.isInteger(n)&&n>=min&&n<=max;}
  function clone(value) {return JSON.parse(JSON.stringify(value));}
  function random(s) {s.rng=(Math.imul(s.rng,1664525)+1013904223)>>>0; return s.rng/4294967296;}
  function note(s,text) {s.log.unshift({turn:s.turn,text});s.log=s.log.slice(0,80);s.message=text;}
  function wealth(s,id) {const p=s.players[id];return p.cash+owned(s,id).reduce((sum,t)=>sum+t.price-(s.deeds[t.id].mortgaged?Math.floor(t.price/2):0)+s.deeds[t.id].level*t.buildCost,0);}
  function rent(s,id) {
    const t=property(s,id),d=s.deeds[id]; if(!t||d.owner===null||d.mortgaged)return 0;
    const complete=ownsGroup(s,d.owner,t.group)&&groupTiles(s,t.group).every(x=>!s.deeds[x.id].mortgaged);
    return t.baseRent*(d.level?[1,4,9,16][d.level]:(complete?2:1));
  }
  function createGame(options={}) {
    const b=BOARDS.find(x=>x.id===(options.boardId||'harbor'));assert(b,'Unknown board.');
    const entries=options.players||[{name:'You',ai:'human'},{name:'Cleo',ai:'balanced'}];
    assert(entries.length>=2&&entries.length<=8,'Choose 2–8 total players.');
    const roundLimit=options.roundLimit===undefined?18:Number(options.roundLimit);
    assert([0,12,18,24,36].includes(roundLimit),'Choose a supported match length.');
    const players=entries.map((p,id)=>{
      assert(['human','relaxed','balanced','bold'].includes(p.ai||'human'),'Unknown player type.');
      return {id,name:String(p.name||`Player ${id+1}`).trim().slice(0,24)||`Player ${id+1}`,ai:p.ai||'human',color:PLAYER_COLORS[id],cash:b.cash,position:0,skipTurns:0,bankrupt:false};
    });
    const s={version:VERSION,boardId:b.id,players,deeds:{},current:0,phase:'roll',round:1,roundLimit,turn:1,dice:[],lastRoll:0,debt:null,auction:null,trade:null,lastEvent:null,log:[],message:'',managementCount:0,tradeAttempted:false,rng:(options.seed===undefined?Date.now():options.seed)>>>0,deck:[],winners:[]};
    b.tiles.filter(t=>t.type==='property').forEach(t=>s.deeds[t.id]={owner:null,level:0,mortgaged:false});
    note(s,`${players[0].name} opens the game. Every great neighborhood starts somewhere.`);
    return s;
  }
  function finish(s,reason) {
    s.phase='finished';s.debt=null;s.auction=null;s.trade=null;
    const living=active(s),max=Math.max(...living.map(p=>wealth(s,p.id)));
    s.winners=living.filter(p=>wealth(s,p.id)===max).map(p=>p.id);
    note(s,`${reason} ${s.winners.map(id=>s.players[id].name).join(' & ')} ${s.winners.length===1?'wins':'share the win'}!`);
  }
  function checkWinner(s) {if(active(s).length<=1){finish(s,'Last player standing.');return true;}return false;}
  function pay(s,amount,creditor,reason) {
    const p=current(s);assert(integer(amount),'Invalid payment.');
    if(p.cash<amount){s.debt={amount,creditor,reason};s.phase='debt';note(s,`${p.name} needs ${amount} credits for ${reason}. Raise cash or concede.`);return;}
    p.cash-=amount;if(creditor!==null)s.players[creditor].cash+=amount;
    s.phase='end';note(s,`${p.name} paid ${amount} credits ${creditor===null?'to the city':`to ${s.players[creditor].name}`} for ${reason}.`);
  }
  function move(s,steps,depth=0) {
    const p=current(s),b=board(s),old=p.position;
    if(steps>0){const laps=Math.floor((old+steps)/b.size);if(laps){p.cash+=laps*b.salary;note(s,`${p.name} collected ${laps*b.salary} credits at Home Port.`);}}
    p.position=((old+steps)%b.size+b.size)%b.size;
    land(s,depth);
  }
  function draw(s,depth) {
    if(!s.deck.length){s.deck=Array.from({length:10},(_,i)=>i);for(let i=s.deck.length-1;i>0;i--){const j=Math.floor(random(s)*(i+1));[s.deck[i],s.deck[j]]=[s.deck[j],s.deck[i]];}}
    const card=s.deck.pop(),p=current(s),b=board(s);
    const cards=[
      ['Community dividend','Your neighborhood fund pays out. Collect 120 credits.'],
      ['Roof repairs','A little upkeep goes a long way. Pay 80 credits.'],
      ['A useful shortcut','Advance 3 stops and resolve your destination.'],
      ['Scenic route','Move back 2 stops and resolve your destination.'],
      ['Homeward bound',`Return to Home Port and collect ${b.salary} credits.`],
      ['Neighborhood festival','Your pop-up is a hit. Collect 90 credits.'],
      ['Annual upkeep','Pay 25 credits per property plus 30 per upgrade.'],
      ['Local commission','A successful project earns you 60 credits.'],
      ['Planning delay','Go to Breather. Next turn, wait or pay 60 to leave.'],
      ['Green grant','Collect 40 credits, plus 20 per property you own.']
    ];
    s.lastEvent={title:cards[card][0],text:cards[card][1]};note(s,`${p.name}: ${cards[card][0]}.`);s.phase='end';
    if(card===0)p.cash+=120;
    else if(card===1)pay(s,80,null,'roof repairs');
    else if(card===2&&depth<5)move(s,3,depth+1);
    else if(card===3&&depth<5)move(s,-2,depth+1);
    else if(card===4){p.position=0;p.cash+=b.salary;}
    else if(card===5)p.cash+=90;
    else if(card===6)pay(s,owned(s,p.id).reduce((v,t)=>v+25+30*s.deeds[t.id].level,0),null,'annual upkeep');
    else if(card===7)p.cash+=60;
    else if(card===8)detour(s);
    else if(card===9)p.cash+=40+owned(s,p.id).length*20;
  }
  function detour(s) {const p=current(s);p.position=board(s).tiles.find(t=>t.type==='rest').id;p.skipTurns=1;s.phase='end';note(s,`${p.name} takes a planning break. Next turn: wait or pay 60.`);}
  function land(s,depth=0) {
    const p=current(s),t=board(s).tiles[p.position];s.phase='end';
    if(t.type==='property') {
      const d=s.deeds[t.id];
      if(d.owner===null){s.phase='offer';note(s,`${t.name} is available for ${t.price} credits.`);}
      else if(d.owner!==p.id&&!d.mortgaged)pay(s,rent(s,t.id),d.owner,`rent at ${t.name}`);
      else note(s,`${p.name} visits ${t.name}. No rent due.`);
    } else if(t.type==='event')draw(s,depth);
    else if(t.type==='fee')pay(s,board(s).fee,null,'the city levy');
    else if(t.type==='detour')detour(s);
    else if(t.type==='dividend'){p.cash+=100;note(s,`${p.name} receives a 100-credit local grant.`);}
    else if(t.type==='rest'){p.cash+=40;note(s,`${p.name} takes a breather and collects 40 credits.`);}
    else note(s,`${p.name} arrives at Home Port.`);
  }
  function startAuction(s) {
    const ids=s.players.filter(p=>!p.bankrupt&&p.cash>=10).map(p=>p.id);
    s.auction={tileId:current(s).position,eligible:ids,leader:null,bid:0,bidder:ids[0]??null};s.phase='auction';
    note(s,`Auction for ${board(s).tiles[s.auction.tileId].name}. Bids start at 10 credits.`);
    if(!ids.length)closeAuction(s);
  }
  function closeAuction(s) {
    const a=s.auction;
    if(a.leader!==null){s.players[a.leader].cash-=a.bid;s.deeds[a.tileId].owner=a.leader;note(s,`${s.players[a.leader].name} won ${property(s,a.tileId).name} for ${a.bid} credits.`);}
    else note(s,`No bids. ${property(s,a.tileId).name} stays available.`);
    s.auction=null;s.phase='end';
  }
  function nextBidder(s,previous) {
    const a=s.auction;
    a.eligible=a.eligible.filter(id=>id===a.leader||s.players[id].cash>=a.bid+10);
    if(a.eligible.length===0||(a.leader!==null&&a.eligible.every(id=>id===a.leader))){closeAuction(s);return;}
    for(let step=1;step<=s.players.length;step++){const id=(previous+step)%s.players.length;if(a.eligible.includes(id)&&id!==a.leader){a.bidder=id;return;}}
    closeAuction(s);
  }
  function canManage(s) {return ['roll','end','debt','offer'].includes(s.phase)&&!current(s).bankrupt;}
  function manageError(s,type,id) {
    if(!canManage(s))return 'Finish the current decision first.';
    const t=property(s,id),p=current(s),d=s.deeds[id];
    if(!t||d.owner!==p.id)return 'You do not own this property.';
    const group=groupTiles(s,t.group),levels=group.map(x=>s.deeds[x.id].level);
    if(type==='build'){
      if(s.phase==='debt')return 'Settle your debt before building.';
      if(!ownsGroup(s,p.id,t.group))return 'Own all three properties in this district first.';
      if(group.some(x=>s.deeds[x.id].mortgaged))return 'Redeem every mortgage in this district first.';
      if(d.level>=3)return 'This property is fully upgraded.';
      if(d.level>Math.min(...levels))return 'Build evenly: upgrade a lower-tier property first.';
      if(p.cash<t.buildCost)return 'Not enough cash for this upgrade.';
    } else if(type==='sell'){
      if(d.level===0)return 'There are no upgrades to sell.';
      if(d.level<Math.max(...levels))return 'Sell evenly: reduce a higher-tier property first.';
    } else if(type==='mortgage'){
      if(d.mortgaged)return 'This property is already mortgaged.';
      if(levels.some(x=>x>0))return 'Sell all upgrades in this district first.';
    } else if(type==='redeem'){
      if(s.phase==='debt')return 'Settle your debt before redeeming mortgages.';
      if(!d.mortgaged)return 'This property is not mortgaged.';
      if(p.cash<redemption(t))return 'Not enough cash to redeem this mortgage.';
    } else return 'Unknown property action.';
    return null;
  }
  function redemption(t) {return Math.ceil(Math.floor(t.price/2)*11/10);}
  function manage(s,type,id) {
    assert(!manageError(s,type,id),manageError(s,type,id));const t=property(s,id),d=s.deeds[id],p=current(s);
    if(type==='build'){p.cash-=t.buildCost;d.level++;note(s,`${p.name} upgraded ${t.name} to tier ${d.level}.`);}
    if(type==='sell'){p.cash+=Math.floor(t.buildCost/2);d.level--;note(s,`${p.name} sold an upgrade at ${t.name}.`);}
    if(type==='mortgage'){p.cash+=Math.floor(t.price/2);d.mortgaged=true;note(s,`${p.name} mortgaged ${t.name}. Rent is paused.`);}
    if(type==='redeem'){p.cash-=redemption(t);d.mortgaged=false;note(s,`${p.name} redeemed ${t.name}. Rent resumes.`);}
    s.managementCount++;
  }
  function tradeable(s,id,owner) {const t=property(s,id);return !!t&&s.deeds[id].owner===owner&&groupTiles(s,t.group).every(x=>s.deeds[x.id].level===0);}
  function validateTrade(s,t) {
    assert(integer(t.target,0,s.players.length-1)&&t.target!==t.proposer&&!s.players[t.target].bankrupt,'Choose another active player.');
    assert(integer(t.giveCash)&&integer(t.takeCash),'Trade amounts must be nonnegative whole credits.');
    assert(t.giveCash<=s.players[t.proposer].cash&&t.takeCash<=s.players[t.target].cash,'A player cannot afford this trade.');
    assert(Array.isArray(t.giveIds)&&Array.isArray(t.takeIds),'Choose valid properties.');
    assert(new Set([...t.giveIds,...t.takeIds]).size===t.giveIds.length+t.takeIds.length,'A property can only appear once.');
    assert(t.giveIds.every(id=>tradeable(s,id,t.proposer))&&t.takeIds.every(id=>tradeable(s,id,t.target)),'Only owned properties in districts without upgrades can be traded.');
    assert(t.giveIds.length+t.takeIds.length+t.giveCash+t.takeCash>0,'Add something to the trade.');
  }
  function act(state,action) {
    assert(state&&state.phase!=='finished','This game has finished.');
    const s=clone(state),p=current(s),type=action.type;
    if(['build','sell','mortgage','redeem'].includes(type)){manage(s,type,action.id);return s;}
    switch(type){
      case 'roll': {
        assert(s.phase==='roll','You cannot roll right now.');s.lastEvent=null;
        if(p.skipTurns){p.skipTurns--;s.dice=[];s.phase='end';note(s,`${p.name} waits out a planning delay.`);break;}
        s.dice=[1+Math.floor(random(s)*6),1+Math.floor(random(s)*6)];s.lastRoll=s.dice[0]+s.dice[1];
        note(s,`${p.name} rolled ${s.dice.join(' + ')}.`);move(s,s.lastRoll);break;
      }
      case 'leave':assert(s.phase==='roll'&&p.skipTurns>0,'There is no delay to clear.');assert(p.cash>=60,'You need 60 credits.');p.cash-=60;p.skipTurns=0;note(s,`${p.name} paid 60 credits to clear the delay.`);break;
      case 'buy': {
        assert(s.phase==='offer','There is no property offer.');const t=property(s,p.position);assert(p.cash>=t.price,'Raise cash or send this property to auction.');s.deeds[t.id].owner=p.id;p.cash-=t.price;s.phase='end';note(s,`${p.name} bought ${t.name} for ${t.price} credits.`);break;
      }
      case 'auction':assert(s.phase==='offer','There is no property offer.');startAuction(s);break;
      case 'bid': {
        assert(s.phase==='auction','There is no auction.');const a=s.auction,id=a.bidder;
        assert(integer(action.amount,a.bid+10,s.players[id].cash),'Bid at least 10 more, within your cash balance.');
        a.bid=action.amount;a.leader=id;note(s,`${s.players[id].name} bids ${a.bid} credits.`);nextBidder(s,id);break;
      }
      case 'pass': {
        assert(s.phase==='auction','There is no auction.');const a=s.auction,id=a.bidder;a.eligible=a.eligible.filter(x=>x!==id);note(s,`${s.players[id].name} left the auction.`);nextBidder(s,id);break;
      }
      case 'settle':assert(s.phase==='debt','There is no payment due.');assert(p.cash>=s.debt.amount,'Raise enough cash first.');{const debt=s.debt;s.debt=null;pay(s,debt.amount,debt.creditor,debt.reason);}break;
      case 'concede': {
        assert(s.phase==='debt','You can concede when you cannot cover a payment.');const creditor=s.debt.creditor;
        if(creditor!==null)s.players[creditor].cash+=p.cash;p.cash=0;p.bankrupt=true;
        owned(s,p.id).forEach(t=>{const d=s.deeds[t.id];d.owner=creditor;if(creditor===null){d.level=0;d.mortgaged=false;}});
        s.debt=null;s.phase='end';note(s,`${p.name} is out. Remaining assets ${creditor===null?'return to the city':`pass to ${s.players[creditor].name}`}.`);checkWinner(s);break;
      }
      case 'end': {
        assert(s.phase==='end','Finish your turn before passing the device.');if(checkWinner(s))break;
        let next=s.current;do{next=(next+1)%s.players.length;}while(s.players[next].bankrupt);
        if(next<=s.current){if(s.roundLimit&&s.round>=s.roundLimit){finish(s,'The final round is complete.');break;}s.round++;}
        s.current=next;s.turn++;s.managementCount=0;s.tradeAttempted=false;s.phase='roll';s.dice=[];s.lastEvent=null;note(s,`${current(s).name}'s turn.`);break;
      }
      case 'propose': {
        assert(['roll','end'].includes(s.phase)&&!p.bankrupt,'Trade before rolling or after resolving your turn.');
        const t={proposer:p.id,target:action.target,giveCash:action.giveCash||0,takeCash:action.takeCash||0,giveIds:action.giveIds||[],takeIds:action.takeIds||[],resumePhase:s.phase};
        validateTrade(s,t);s.tradeAttempted=true;s.trade=t;s.phase='trade';note(s,`${p.name} proposed a trade to ${s.players[t.target].name}.`);break;
      }
      case 'accept': case 'reject': {
        assert(s.phase==='trade','There is no trade to review.');const t=s.trade;
        if(type==='accept'){validateTrade(s,t);s.players[t.proposer].cash+=t.takeCash-t.giveCash;s.players[t.target].cash+=t.giveCash-t.takeCash;t.giveIds.forEach(id=>s.deeds[id].owner=t.target);t.takeIds.forEach(id=>s.deeds[id].owner=t.proposer);note(s,`${s.players[t.target].name} accepted the trade.`);}
        else note(s,`${s.players[t.target].name} declined the trade.`);
        s.phase=t.resumePhase;s.trade=null;break;
      }
      default:throw new Error('Unknown action.');
    }
    return s;
  }
  function decisionPlayer(s) {if(s.phase==='auction')return s.players[s.auction.bidder];if(s.phase==='trade')return s.players[s.trade.target];return current(s);}
  function valueFor(s,id,t) {
    const p=s.players[id],peers=groupTiles(s,t.group).filter(x=>x.id!==t.id),count=peers.filter(x=>s.deeds[x.id].owner===id).length;
    let multiple=p.ai==='relaxed'?0.9:p.ai==='bold'?1.2:1.03;
    multiple+=count*(p.ai==='bold'?0.5:0.28);
    if(p.ai==='bold'&&peers.every(x=>s.deeds[x.id].owner!==null&&s.deeds[x.id].owner===s.deeds[peers[0].id].owner))multiple+=0.2;
    return Math.floor(t.price*multiple)-(s.deeds[t.id].mortgaged?redemption(t):0);
  }
  function botAction(s) {
    if(s.phase==='finished')return null;const p=decisionPlayer(s);if(p.ai==='human')return null;
    const reserve=p.ai==='relaxed'?330:p.ai==='bold'?100:220;
    if(s.phase==='auction') {const a=s.auction,t=property(s,a.tileId),amount=a.bid+10;return amount<=Math.min(valueFor(s,p.id,t),p.cash-reserve)?{type:'bid',amount}:{type:'pass'};}
    if(s.phase==='trade') {
      const t=s.trade;
      // Evaluate the portfolio *after* the proposed swap, so completed districts matter.
      const post=clone(s);t.giveIds.forEach(id=>post.deeds[id].owner=p.id);t.takeIds.forEach(id=>post.deeds[id].owner=t.proposer);
      const gain=t.giveCash+t.giveIds.reduce((n,id)=>n+valueFor(post,p.id,property(s,id)),0);
      const loss=t.takeCash+t.takeIds.reduce((n,id)=>n+valueFor(s,p.id,property(s,id)),0);
      return {type:gain>=loss*(p.ai==='relaxed'?0.9:1.05)&&p.cash+t.giveCash-t.takeCash>=reserve?'accept':'reject'};
    }
    if(s.phase==='debt') {
      if(p.cash>=s.debt.amount)return {type:'settle'};
      const sale=owned(s,p.id).filter(t=>!manageError(s,'sell',t.id)).sort((a,b)=>b.buildCost-a.buildCost)[0];if(sale)return {type:'sell',id:sale.id};
      const mortgage=owned(s,p.id).filter(t=>!manageError(s,'mortgage',t.id)).sort((a,b)=>rent(s,a.id)-rent(s,b.id))[0];if(mortgage)return {type:'mortgage',id:mortgage.id};
      return {type:'concede'};
    }
    if(s.phase==='offer') {const t=property(s,p.position);return {type:p.cash-t.price>=reserve?'buy':'auction'};}
    if(s.phase==='roll')return {type:p.skipTurns&&p.cash>reserve+60?'leave':'roll'};
    if(s.phase==='end') {
      if(s.managementCount<5){
        const redeem=owned(s,p.id).find(t=>!manageError(s,'redeem',t.id)&&p.cash-redemption(t)>reserve);if(redeem)return {type:'redeem',id:redeem.id};
        const build=owned(s,p.id).filter(t=>!manageError(s,'build',t.id)&&p.cash-t.buildCost>reserve).sort((a,b)=>b.baseRent-a.baseRent)[0];if(build)return {type:'build',id:build.id};
      }
      if(!s.tradeAttempted&&p.ai!=='relaxed'){
        for(const t of board(s).tiles.filter(x=>x.type==='property')){
          const owner=s.deeds[t.id].owner;
          if(owner===null||owner===p.id||!tradeable(s,t.id,owner))continue;
          const peers=groupTiles(s,t.group).filter(x=>x.id!==t.id);
          if(!peers.every(x=>s.deeds[x.id].owner===p.id))continue;
          const offer=Math.ceil(Math.max(t.price*1.45,valueFor(s,owner,t)*1.15)/10)*10;
          if(p.cash-offer>reserve)return {type:'propose',target:owner,giveCash:offer,takeCash:0,giveIds:[],takeIds:[t.id]};
        }
      }
      return {type:'end'};
    }
    return null;
  }
  function validate(s) {
    assert(s&&s.version===VERSION,'This save uses an unsupported version.');const b=board(s);assert(b,'Invalid board in save.');
    assert(Array.isArray(s.players)&&s.players.length>=2&&s.players.length<=8,'Invalid players in save.');
    s.players.forEach((p,i)=>assert(p.id===i&&typeof p.name==='string'&&p.name.length>0&&p.name.length<=24&&typeof p.bankrupt==='boolean'&&['human','relaxed','balanced','bold'].includes(p.ai)&&integer(p.cash)&&integer(p.position,0,b.size-1)&&integer(p.skipTurns,0,1),'Invalid player in save.'));
    assert(integer(s.current,0,s.players.length-1)&&integer(s.round,1)&&integer(s.turn,1)&&integer(s.rng,0,4294967295)&&integer(s.managementCount)&&typeof s.tradeAttempted==='boolean','Invalid turn in save.');
    assert([0,12,18,24,36].includes(s.roundLimit)&&['roll','end','offer','auction','debt','trade','finished'].includes(s.phase),'Invalid phase in save.');
    assert(s.deeds&&Object.keys(s.deeds).length===b.tiles.filter(t=>t.type==='property').length,'Invalid property list.');
    b.tiles.filter(t=>t.type==='property').forEach(t=>{const d=s.deeds[t.id];assert(d&&(d.owner===null||integer(d.owner,0,s.players.length-1))&&integer(d.level,0,3)&&typeof d.mortgaged==='boolean','Invalid deed in save.');assert(d.owner!==null||(!d.mortgaged&&d.level===0),'Unowned property has assets.');assert(!(d.mortgaged&&d.level),'Mortgaged property cannot have upgrades.');if(d.owner!==null)assert(!s.players[d.owner].bankrupt,'Eliminated player owns property.');});
    for(let group=0;group<b.districts.length;group++){const tiles=groupTiles(s,group),deeds=tiles.map(t=>s.deeds[t.id]);if(deeds.some(d=>d.level>0))assert(deeds.every(d=>d.owner===deeds[0].owner&&!d.mortgaged)&&Math.max(...deeds.map(d=>d.level))-Math.min(...deeds.map(d=>d.level))<=1,'Invalid district upgrades.');}
    assert(Array.isArray(s.deck)&&new Set(s.deck).size===s.deck.length&&s.deck.every(n=>integer(n,0,9)),'Invalid dispatch deck.');
    assert(Array.isArray(s.dice)&&[0,2].includes(s.dice.length)&&s.dice.every(n=>integer(n,1,6)),'Invalid dice in save.');
    assert(Array.isArray(s.log)&&s.log.length<=80&&s.log.every(x=>integer(x.turn,1)&&typeof x.text==='string'&&x.text.length<1000),'Invalid activity log.');
    assert(typeof s.message==='string'&&s.message.length<1000,'Invalid message.');
    assert(s.lastEvent===null||(typeof s.lastEvent.title==='string'&&typeof s.lastEvent.text==='string'&&s.lastEvent.title.length<100&&s.lastEvent.text.length<500),'Invalid dispatch.');
    assert(Array.isArray(s.winners)&&s.winners.every(id=>integer(id,0,s.players.length-1)),'Invalid winners.');
    if(s.phase!=='finished'&&s.phase!=='end')assert(!current(s).bankrupt,'Invalid active player.');
    if(s.phase==='offer')assert(property(s,current(s).position)&&s.deeds[current(s).position].owner===null,'Invalid property offer.');
    if(s.phase==='debt')assert(s.debt&&integer(s.debt.amount,1)&&(s.debt.creditor===null||(integer(s.debt.creditor,0,s.players.length-1)&&s.debt.creditor!==s.current&&!s.players[s.debt.creditor].bankrupt))&&typeof s.debt.reason==='string'&&s.debt.reason.length<300,'Invalid debt.');else assert(s.debt===null,'Unexpected debt.');
    if(s.phase==='auction'){const a=s.auction;assert(a&&property(s,a.tileId)&&s.deeds[a.tileId].owner===null&&integer(a.bid)&&Array.isArray(a.eligible)&&a.eligible.length>0&&new Set(a.eligible).size===a.eligible.length&&a.eligible.every(id=>integer(id,0,s.players.length-1)&&!s.players[id].bankrupt)&&a.eligible.includes(a.bidder)&&a.bidder!==a.leader,'Invalid auction.');assert(a.leader===null?a.bid===0:(a.eligible.includes(a.leader)&&a.bid>=10&&a.bid<=s.players[a.leader].cash),'Invalid winning bid.');}else assert(s.auction===null,'Unexpected auction.');
    if(s.phase==='trade'){assert(s.trade&&s.trade.proposer===s.current&&['roll','end'].includes(s.trade.resumePhase),'Invalid trade.');validateTrade(s,s.trade);}else assert(s.trade===null,'Unexpected trade.');
    return s;
  }
  function serialize(s) {validate(s);return JSON.stringify(s);}
  function restore(text) {assert(typeof text==='string'&&text.length<=500000,'This save is too large.');return validate(JSON.parse(text));}
  return {VERSION,BOARDS,PLAYER_COLORS,board,current,active,owned,ownsGroup,groupTiles,property,rent,wealth,redemption,createGame,act,botAction,decisionPlayer,manageError,tradeable,serialize,restore,validate};
});
