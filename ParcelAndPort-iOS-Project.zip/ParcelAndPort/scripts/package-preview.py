#!/usr/bin/env python3
"""Produce a standalone desktop preview from the exact bundled game resources."""
from pathlib import Path
import base64
root = Path(__file__).resolve().parents[1]
web = root / "ios" / "ParcelAndPort" / "Web"
page = (web / "index.html").read_text()
for name in ("style.css", "deluxe.css"):
    css = (web / name).read_text()
    if name == "deluxe.css":
        encoded = base64.b64encode((web / "assets/worlds.png").read_bytes()).decode("ascii")
        css = css.replace('url("assets/worlds.png")', 'url("data:image/png;base64,' + encoded + '")')
    page = page.replace(f'<link rel="stylesheet" href="{name}">', '<style>\n' + css + '\n</style>')
for name in ("engine.js", "visuals.js", "app.js"):
    code = (web / name).read_text().replace('</script', '<\\/script')
    page = page.replace(f'<script src="{name}"></script>', '<script>\n' + code + '\n</script>')
output = root / "ParcelAndPort-Play.html"
output.write_text(page)
print(output)
